import React from 'react'

import PropTypes from 'prop-types'

import './button.css'

const Button = (props) => {
  return (
    <div className="button-container">
      <button className="thq-button-outline button-button">
        <span className="thq-body-small">{props.text}</span>
      </button>
    </div>
  )
}

Button.defaultProps = {
  text: 'Contact Us',
}

Button.propTypes = {
  text: PropTypes.string,
}

export default Button
