import React from 'react'

import './component.css'

const AppComponent = (props) => {
  return <div className="app-component-container"></div>
}

export default AppComponent
