import React from 'react'

import PropTypes from 'prop-types'

import './testimonial16.css'

const Testimonial16 = (props) => {
  return (
    <div className="thq-section-padding">
      <div className="testimonial16-max-width thq-section-max-width">
        <div className="testimonial16-container">
          <h2 className="thq-heading-2">{props.heading1}</h2>
          <span className="testimonial16-text01 thq-body-small">
            {props.content1}
          </span>
        </div>
        <div className="thq-grid-2">
          <div className="testimonial16-container02 thq-card">
            <div className="testimonial16-container03">
              <img
                alt={props.author1Alt}
                src={props.author1Src}
                className="testimonial16-image"
              />
              <div className="testimonial16-container04">
                <strong className="thq-body-large">{props.author1Name}</strong>
                <span className="thq-body-small">{props.author1Position}</span>
              </div>
            </div>
            <span className="testimonial16-text04 thq-body-small">
              {props.review1}
            </span>
          </div>
          <div className="testimonial16-container05 thq-card">
            <div className="testimonial16-container06">
              <img
                alt={props.author2Alt}
                src={props.author2Src}
                className="testimonial16-image1"
              />
              <div className="testimonial16-container07">
                <strong className="thq-body-large">{props.author2Name}</strong>
                <span className="thq-body-small">{props.author2Position}</span>
              </div>
            </div>
            <span className="testimonial16-text07 thq-body-small">
              {props.review2}
            </span>
          </div>
          <div className="testimonial16-container08 thq-card">
            <div className="testimonial16-container09">
              <img
                alt={props.author3Alt}
                src={props.author3Src}
                className="testimonial16-image2"
              />
              <div className="testimonial16-container10">
                <strong className="thq-body-large">{props.author3Name}</strong>
                <span className="thq-body-small">{props.author3Position}</span>
              </div>
            </div>
            <span className="testimonial16-text10 thq-body-small">
              {props.review3}
            </span>
          </div>
          <div className="testimonial16-container11 thq-card">
            <div className="testimonial16-container12">
              <img
                alt={props.author4Alt}
                src={props.author4Src}
                className="testimonial16-image3"
              />
              <div className="testimonial16-container13">
                <strong className="thq-body-large">{props.author4Name}</strong>
                <span className="thq-body-small">{props.author4Position}</span>
              </div>
            </div>
            <span className="testimonial16-text13 thq-body-small">
              {props.review4}
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}

Testimonial16.defaultProps = {
  author1Position: 'CEO, ABC Company',
  content1:
    'Read what our clients have to say about their experience working with RoyTechInnovations.',
  heading1: 'Testimonials',
  author2Src:
    'https://images.unsplash.com/photo-1459245330819-1b6d75fbaa35?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyM3w&ixlib=rb-4.0.3&q=80&w=1080',
  author4Name: 'Sarah Wilson',
  author1Name: 'John Smith',
  author1Alt: 'CEO John Smith',
  review1:
    'RoyTechInnovations has truly transformed our business with their innovative solutions. We have seen a significant increase in efficiency and customer satisfaction since implementing their technology.',
  author4Alt: 'CFO Sarah Wilson',
  author2Name: 'Emily Johnson',
  review3:
    "I can't thank RoyTechInnovations enough for the positive impact they've had on our business. Their cutting-edge solutions have given us a competitive edge in the market.",
  author3Alt: 'COO Michael Brown',
  author3Name: 'Michael Brown',
  author4Src:
    'https://images.unsplash.com/photo-1501432377862-3d0432b87a14?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNHw&ixlib=rb-4.0.3&q=80&w=1080',
  author4Position: 'CFO, GHI Industries',
  author2Position: 'CTO, XYZ Corporation',
  review4:
    'RoyTechInnovations exceeded our expectations in every way. Their commitment to customer satisfaction is evident in the results they deliver. We look forward to continuing our partnership.',
  review2:
    "Working with RoyTechInnovations was a game-changer for us. Their team's dedication to quality and attention to detail is unparalleled. We highly recommend their services.",
  author1Src:
    'https://images.unsplash.com/photo-1469334031218-e382a71b716b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNHw&ixlib=rb-4.0.3&q=80&w=1080',
  author3Src:
    'https://images.unsplash.com/photo-1520283818086-3f6dffb019c0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNHw&ixlib=rb-4.0.3&q=80&w=1080',
  author3Position: 'COO, DEF Enterprises',
  author2Alt: 'CTO Emily Johnson',
}

Testimonial16.propTypes = {
  author1Position: PropTypes.string,
  content1: PropTypes.string,
  heading1: PropTypes.string,
  author2Src: PropTypes.string,
  author4Name: PropTypes.string,
  author1Name: PropTypes.string,
  author1Alt: PropTypes.string,
  review1: PropTypes.string,
  author4Alt: PropTypes.string,
  author2Name: PropTypes.string,
  review3: PropTypes.string,
  author3Alt: PropTypes.string,
  author3Name: PropTypes.string,
  author4Src: PropTypes.string,
  author4Position: PropTypes.string,
  author2Position: PropTypes.string,
  review4: PropTypes.string,
  review2: PropTypes.string,
  author1Src: PropTypes.string,
  author3Src: PropTypes.string,
  author3Position: PropTypes.string,
  author2Alt: PropTypes.string,
}

export default Testimonial16
