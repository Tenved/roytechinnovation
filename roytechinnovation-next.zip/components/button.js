import React from 'react'

import PropTypes from 'prop-types'

const Button = (props) => {
  return (
    <>
      <div className="button-container">
        <button className="thq-button-outline button-button">
          <span className="thq-body-small">{props.text}</span>
        </button>
      </div>
      <style jsx>
        {`
          .button-container {
            display: flex;
            position: relative;
          }
          @media (max-width: 479px) {
            .button-button {
              width: 100%;
            }
          }
        `}
      </style>
    </>
  )
}

Button.defaultProps = {
  text: 'Contact Us',
}

Button.propTypes = {
  text: PropTypes.string,
}

export default Button
