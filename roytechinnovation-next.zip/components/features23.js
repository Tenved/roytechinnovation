import React from 'react'

import PropTypes from 'prop-types'

const Features23 = (props) => {
  return (
    <>
      <div className="features23-layout349 thq-section-padding">
        <div className="features23-max-width thq-section-max-width">
          <div className="features23-container">
            <h2 className="thq-heading-2">{props.heading1}</h2>
            <span className="features23-text01 thq-body-small">
              {props.content1}
            </span>
            <button className="thq-button-filled features23-button">
              <span className="thq-body-small">{props.action1}</span>
            </button>
          </div>
          <div className="thq-grid-3">
            <div className="features23-container2 thq-card">
              <img
                alt={props.feature1ImageAlt}
                src={props.feature1ImageSrc}
                className="features23-image thq-img-round"
              />
              <h2 className="thq-heading-2">{props.feature1Title}</h2>
              <span className="features23-text03 thq-body-small">
                {props.feature1Description}
              </span>
            </div>
            <div className="features23-container3 thq-card">
              <img
                alt={props.feature2ImageAlt}
                src={props.feature2ImageSrc}
                className="features23-image1 thq-img-round"
              />
              <h2 className="thq-heading-2">{props.feature2Title}</h2>
              <span className="features23-text05 thq-body-small">
                {props.feature2Description}
              </span>
            </div>
            <div className="features23-container4 thq-card">
              <img
                alt={props.feature3ImageAlt}
                src={props.feature3ImageSrc}
                className="features23-image2 thq-img-round"
              />
              <h2 className="thq-heading-2">{props.feature3Title}</h2>
              <span className="features23-text07 thq-body-small">
                {props.feature3Description}
              </span>
            </div>
            <div className="features23-container5 thq-card">
              <img
                alt={props.feature4ImageAlt}
                src={props.feature4ImageSrc}
                className="features23-image3 thq-img-round"
              />
              <h2 className="thq-heading-2">{props.feature4Title}</h2>
              <span className="features23-text09 thq-body-small">
                {props.feature4Description}
              </span>
            </div>
            <div className="features23-container6 thq-card">
              <img
                alt={props.feature5ImageAlt}
                src={props.feature5ImageSrc}
                className="features23-image4 thq-img-round"
              />
              <h2 className="thq-heading-2">{props.feature5Title}</h2>
              <span className="features23-text11 thq-body-small">
                {props.feature5Description}
              </span>
            </div>
            <div className="features23-container7 thq-card">
              <img
                alt={props.feature6ImageAlt}
                src={props.feature6ImageSrc}
                className="features23-image5 thq-img-round"
              />
              <h2 className="thq-heading-2">{props.feature6Title}</h2>
              <span className="features23-text13 thq-body-small">
                {props.feature6Description}
              </span>
            </div>
          </div>
        </div>
      </div>
      <style jsx>
        {`
          .features23-layout349 {
            gap: var(--dl-space-space-twounits);
            display: flex;
            overflow: hidden;
            position: relative;
            align-items: flex-start;
            flex-direction: row;
            justify-content: center;
          }
          .features23-max-width {
            gap: var(--dl-space-space-threeunits);
            display: flex;
            align-items: center;
            flex-direction: column;
          }
          .features23-container {
            gap: var(--dl-space-space-unit);
            display: flex;
            max-width: 600px;
            align-items: center;
            flex-direction: column;
          }
          .features23-text01 {
            text-align: center;
          }
          .features23-container2 {
            flex: 1;
            height: auto;
            display: flex;
            align-self: flex-start;
            box-shadow: 2px 2px 4px 0px #d4d4d4;
            align-items: flex-start;
            flex-direction: column;
            justify-content: center;
            background-color: var(--dl-color-theme-accent1);
          }
          .features23-image {
            width: var(--dl-size-size-small);
            height: var(--dl-size-size-small);
            object-fit: cover;
            border-radius: var(--dl-radius-radius-round);
          }
          .features23-text03 {
            text-align: left;
          }
          .features23-container3 {
            flex: 1;
            height: auto;
            display: flex;
            align-self: flex-start;
            box-shadow: 2px 2px 4px 0px #d4d4d4;
            align-items: flex-start;
            flex-direction: column;
            justify-content: center;
            background-color: var(--dl-color-theme-accent2);
          }
          .features23-image1 {
            width: var(--dl-size-size-small);
            height: var(--dl-size-size-small);
            object-fit: cover;
            border-radius: var(--dl-radius-radius-round);
          }
          .features23-text05 {
            text-align: left;
          }
          .features23-container4 {
            flex: 1;
            height: auto;
            display: flex;
            align-self: flex-start;
            box-shadow: 2px 2px 4px 0px #d4d4d4;
            align-items: flex-start;
            flex-direction: column;
            justify-content: center;
            background-color: var(--dl-color-theme-accent1);
          }
          .features23-image2 {
            width: var(--dl-size-size-small);
            height: var(--dl-size-size-small);
            object-fit: cover;
            border-radius: var(--dl-radius-radius-round);
          }
          .features23-text07 {
            text-align: left;
          }
          .features23-container5 {
            flex: 1;
            height: auto;
            display: flex;
            align-self: flex-start;
            box-shadow: 2px 2px 4px 0px #d4d4d4;
            align-items: flex-start;
            flex-direction: column;
            justify-content: center;
            background-color: var(--dl-color-theme-accent2);
          }
          .features23-image3 {
            width: var(--dl-size-size-small);
            height: var(--dl-size-size-small);
            object-fit: cover;
            border-radius: var(--dl-radius-radius-round);
          }
          .features23-text09 {
            text-align: left;
          }
          .features23-container6 {
            flex: 1;
            height: auto;
            display: flex;
            align-self: flex-start;
            box-shadow: 2px 2px 4px 0px #d4d4d4;
            align-items: flex-start;
            flex-direction: column;
            justify-content: center;
            background-color: var(--dl-color-theme-accent1);
          }
          .features23-image4 {
            width: var(--dl-size-size-small);
            height: var(--dl-size-size-small);
            object-fit: cover;
            border-radius: var(--dl-radius-radius-round);
          }
          .features23-text11 {
            text-align: left;
          }
          .features23-container7 {
            flex: 1;
            height: auto;
            display: flex;
            align-self: flex-start;
            box-shadow: 2px 2px 4px 0px #d4d4d4;
            align-items: flex-start;
            flex-direction: column;
            justify-content: center;
            background-color: var(--dl-color-theme-accent2);
          }
          .features23-image5 {
            width: var(--dl-size-size-small);
            height: var(--dl-size-size-small);
            object-fit: cover;
            border-radius: var(--dl-radius-radius-round);
          }
          .features23-text13 {
            text-align: left;
          }
          @media (max-width: 991px) {
            .features23-max-width {
              flex-direction: column;
            }
            .features23-container {
              margin-bottom: var(--dl-space-space-threeunits);
            }
          }
          @media (max-width: 767px) {
            .features23-container {
              margin-bottom: var(--dl-space-space-oneandhalfunits);
            }
            .features23-container2 {
              width: 100%;
            }
            .features23-container3 {
              width: 100%;
            }
            .features23-container4 {
              width: 100%;
            }
            .features23-container5 {
              width: 100%;
            }
            .features23-container6 {
              width: 100%;
            }
            .features23-container7 {
              width: 100%;
            }
          }
          @media (max-width: 479px) {
            .features23-max-width {
              gap: var(--dl-space-space-oneandhalfunits);
            }
            .features23-button {
              width: 100%;
            }
          }
        `}
      </style>
    </>
  )
}

Features23.defaultProps = {
  content1:
    'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla.',
  feature6Title: '24/7 Support',
  feature3ImageSrc:
    'https://images.unsplash.com/photo-1518349619113-03114f06ac3a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNnw&ixlib=rb-4.0.3&q=80&w=1080',
  feature6Description:
    'Our dedicated support team is available round the clock to assist clients with any queries or issues.',
  feature1ImageSrc:
    'https://images.unsplash.com/photo-1616410011236-7a42121dd981?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNXw&ixlib=rb-4.0.3&q=80&w=1080',
  feature4ImageSrc: 'https://play.teleporthq.io/static/svg/default-img.svg',
  feature5Description:
    'Customer happiness is our top priority, and we strive to exceed expectations in every interaction.',
  feature4Description:
    'We streamline processes and optimize resources to enhance efficiency and productivity.',
  feature3ImageAlt: 'Quality Assurance Image',
  feature2Title: 'Innovation',
  feature6ImageSrc:
    'https://images.unsplash.com/photo-1556710808-a2bc27a448f2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNnw&ixlib=rb-4.0.3&q=80&w=1080',
  feature4ImageAlt: 'Efficiency Image',
  feature5ImageAlt: 'Customer Satisfaction Image',
  feature1ImageAlt: 'Tailored Solutions Image',
  feature3Description:
    'Our products and services undergo rigorous quality checks to ensure high standards are maintained.',
  feature1Title: 'Tailored Solutions',
  feature5Title: 'Customer Satisfaction',
  feature4Title: 'Efficiency',
  feature3Title: 'Quality Assurance',
  feature2Description:
    'We focus on cutting-edge technology and innovative solutions to drive business growth.',
  feature5ImageSrc:
    'https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNXw&ixlib=rb-4.0.3&q=80&w=1080',
  feature2ImageSrc:
    'https://images.unsplash.com/photo-1589828994425-cee7c6e8dbf8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNHw&ixlib=rb-4.0.3&q=80&w=1080',
  heading1: 'Our Features',
  feature2ImageAlt: 'Innovation Image',
  action1: 'Learn More',
  feature1Description:
    'We provide customized services and products to meet the specific needs of each client.',
  feature6ImageAlt: '24/7 Support Image',
}

Features23.propTypes = {
  content1: PropTypes.string,
  feature6Title: PropTypes.string,
  feature3ImageSrc: PropTypes.string,
  feature6Description: PropTypes.string,
  feature1ImageSrc: PropTypes.string,
  feature4ImageSrc: PropTypes.string,
  feature5Description: PropTypes.string,
  feature4Description: PropTypes.string,
  feature3ImageAlt: PropTypes.string,
  feature2Title: PropTypes.string,
  feature6ImageSrc: PropTypes.string,
  feature4ImageAlt: PropTypes.string,
  feature5ImageAlt: PropTypes.string,
  feature1ImageAlt: PropTypes.string,
  feature3Description: PropTypes.string,
  feature1Title: PropTypes.string,
  feature5Title: PropTypes.string,
  feature4Title: PropTypes.string,
  feature3Title: PropTypes.string,
  feature2Description: PropTypes.string,
  feature5ImageSrc: PropTypes.string,
  feature2ImageSrc: PropTypes.string,
  heading1: PropTypes.string,
  feature2ImageAlt: PropTypes.string,
  action1: PropTypes.string,
  feature1Description: PropTypes.string,
  feature6ImageAlt: PropTypes.string,
}

export default Features23
