<template>
  <div class="features23-layout349 thq-section-padding">
    <div class="features23-max-width thq-section-max-width">
      <div class="features23-container">
        <h2 class="thq-heading-2">{{ heading1 }}</h2>
        <span class="features23-text01 thq-body-small">{{ content1 }}</span>
        <button class="thq-button-filled features23-button">
          <span class="thq-body-small">{{ action1 }}</span>
        </button>
      </div>
      <div class="thq-grid-3">
        <div class="features23-container2 thq-card">
          <img
            :alt="feature1ImageAlt"
            :src="feature1ImageSrc"
            class="features23-image thq-img-round"
          />
          <h2 class="thq-heading-2">{{ feature1Title }}</h2>
          <span class="features23-text03 thq-body-small">
            {{ feature1Description }}
          </span>
        </div>
        <div class="features23-container3 thq-card">
          <img
            :alt="feature2ImageAlt"
            :src="feature2ImageSrc"
            class="features23-image1 thq-img-round"
          />
          <h2 class="thq-heading-2">{{ feature2Title }}</h2>
          <span class="features23-text05 thq-body-small">
            {{ feature2Description }}
          </span>
        </div>
        <div class="features23-container4 thq-card">
          <img
            :alt="feature3ImageAlt"
            :src="feature3ImageSrc"
            class="features23-image2 thq-img-round"
          />
          <h2 class="thq-heading-2">{{ feature3Title }}</h2>
          <span class="features23-text07 thq-body-small">
            {{ feature3Description }}
          </span>
        </div>
        <div class="features23-container5 thq-card">
          <img
            :alt="feature4ImageAlt"
            :src="feature4ImageSrc"
            class="features23-image3 thq-img-round"
          />
          <h2 class="thq-heading-2">{{ feature4Title }}</h2>
          <span class="features23-text09 thq-body-small">
            {{ feature4Description }}
          </span>
        </div>
        <div class="features23-container6 thq-card">
          <img
            :alt="feature5ImageAlt"
            :src="feature5ImageSrc"
            class="features23-image4 thq-img-round"
          />
          <h2 class="thq-heading-2">{{ feature5Title }}</h2>
          <span class="features23-text11 thq-body-small">
            {{ feature5Description }}
          </span>
        </div>
        <div class="features23-container7 thq-card">
          <img
            :alt="feature6ImageAlt"
            :src="feature6ImageSrc"
            class="features23-image5 thq-img-round"
          />
          <h2 class="thq-heading-2">{{ feature6Title }}</h2>
          <span class="features23-text13 thq-body-small">
            {{ feature6Description }}
          </span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Features23',
  props: {
    content1: {
      type: String,
      default:
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla.',
    },
    feature6Title: {
      type: String,
      default: '24/7 Support',
    },
    feature3ImageSrc: {
      type: String,
      default:
        'https://images.unsplash.com/photo-1518349619113-03114f06ac3a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNnw&ixlib=rb-4.0.3&q=80&w=1080',
    },
    feature6Description: {
      type: String,
      default:
        'Our dedicated support team is available round the clock to assist clients with any queries or issues.',
    },
    feature1ImageSrc: {
      type: String,
      default:
        'https://images.unsplash.com/photo-1616410011236-7a42121dd981?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNXw&ixlib=rb-4.0.3&q=80&w=1080',
    },
    feature4ImageSrc: {
      type: String,
      default: 'https://play.teleporthq.io/static/svg/default-img.svg',
    },
    feature5Description: {
      type: String,
      default:
        'Customer happiness is our top priority, and we strive to exceed expectations in every interaction.',
    },
    feature4Description: {
      type: String,
      default:
        'We streamline processes and optimize resources to enhance efficiency and productivity.',
    },
    feature3ImageAlt: {
      type: String,
      default: 'Quality Assurance Image',
    },
    feature2Title: {
      type: String,
      default: 'Innovation',
    },
    feature6ImageSrc: {
      type: String,
      default:
        'https://images.unsplash.com/photo-1556710808-a2bc27a448f2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNnw&ixlib=rb-4.0.3&q=80&w=1080',
    },
    feature4ImageAlt: {
      type: String,
      default: 'Efficiency Image',
    },
    feature5ImageAlt: {
      type: String,
      default: 'Customer Satisfaction Image',
    },
    feature1ImageAlt: {
      type: String,
      default: 'Tailored Solutions Image',
    },
    feature3Description: {
      type: String,
      default:
        'Our products and services undergo rigorous quality checks to ensure high standards are maintained.',
    },
    feature1Title: {
      type: String,
      default: 'Tailored Solutions',
    },
    feature5Title: {
      type: String,
      default: 'Customer Satisfaction',
    },
    feature4Title: {
      type: String,
      default: 'Efficiency',
    },
    feature3Title: {
      type: String,
      default: 'Quality Assurance',
    },
    feature2Description: {
      type: String,
      default:
        'We focus on cutting-edge technology and innovative solutions to drive business growth.',
    },
    feature5ImageSrc: {
      type: String,
      default:
        'https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNXw&ixlib=rb-4.0.3&q=80&w=1080',
    },
    feature2ImageSrc: {
      type: String,
      default:
        'https://images.unsplash.com/photo-1589828994425-cee7c6e8dbf8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNHw&ixlib=rb-4.0.3&q=80&w=1080',
    },
    heading1: {
      type: String,
      default: 'Our Features',
    },
    feature2ImageAlt: {
      type: String,
      default: 'Innovation Image',
    },
    action1: {
      type: String,
      default: 'Learn More',
    },
    feature1Description: {
      type: String,
      default:
        'We provide customized services and products to meet the specific needs of each client.',
    },
    feature6ImageAlt: {
      type: String,
      default: '24/7 Support Image',
    },
  },
}
</script>

<style scoped>
.features23-layout349 {
  gap: var(--dl-space-space-twounits);
  display: flex;
  overflow: hidden;
  position: relative;
  align-items: flex-start;
  flex-direction: row;
  justify-content: center;
}
.features23-max-width {
  gap: var(--dl-space-space-threeunits);
  display: flex;
  align-items: center;
  flex-direction: column;
}
.features23-container {
  gap: var(--dl-space-space-unit);
  display: flex;
  max-width: 600px;
  align-items: center;
  flex-direction: column;
}
.features23-text01 {
  text-align: center;
}
.features23-container2 {
  flex: 1;
  height: auto;
  display: flex;
  align-self: flex-start;
  box-shadow: 2px 2px 4px 0px #d4d4d4;
  align-items: flex-start;
  flex-direction: column;
  justify-content: center;
  background-color: var(--dl-color-theme-accent1);
}
.features23-image {
  width: var(--dl-size-size-small);
  height: var(--dl-size-size-small);
  object-fit: cover;
  border-radius: var(--dl-radius-radius-round);
}
.features23-text03 {
  text-align: left;
}
.features23-container3 {
  flex: 1;
  height: auto;
  display: flex;
  align-self: flex-start;
  box-shadow: 2px 2px 4px 0px #d4d4d4;
  align-items: flex-start;
  flex-direction: column;
  justify-content: center;
  background-color: var(--dl-color-theme-accent2);
}
.features23-image1 {
  width: var(--dl-size-size-small);
  height: var(--dl-size-size-small);
  object-fit: cover;
  border-radius: var(--dl-radius-radius-round);
}
.features23-text05 {
  text-align: left;
}
.features23-container4 {
  flex: 1;
  height: auto;
  display: flex;
  align-self: flex-start;
  box-shadow: 2px 2px 4px 0px #d4d4d4;
  align-items: flex-start;
  flex-direction: column;
  justify-content: center;
  background-color: var(--dl-color-theme-accent1);
}
.features23-image2 {
  width: var(--dl-size-size-small);
  height: var(--dl-size-size-small);
  object-fit: cover;
  border-radius: var(--dl-radius-radius-round);
}
.features23-text07 {
  text-align: left;
}
.features23-container5 {
  flex: 1;
  height: auto;
  display: flex;
  align-self: flex-start;
  box-shadow: 2px 2px 4px 0px #d4d4d4;
  align-items: flex-start;
  flex-direction: column;
  justify-content: center;
  background-color: var(--dl-color-theme-accent2);
}
.features23-image3 {
  width: var(--dl-size-size-small);
  height: var(--dl-size-size-small);
  object-fit: cover;
  border-radius: var(--dl-radius-radius-round);
}
.features23-text09 {
  text-align: left;
}
.features23-container6 {
  flex: 1;
  height: auto;
  display: flex;
  align-self: flex-start;
  box-shadow: 2px 2px 4px 0px #d4d4d4;
  align-items: flex-start;
  flex-direction: column;
  justify-content: center;
  background-color: var(--dl-color-theme-accent1);
}
.features23-image4 {
  width: var(--dl-size-size-small);
  height: var(--dl-size-size-small);
  object-fit: cover;
  border-radius: var(--dl-radius-radius-round);
}
.features23-text11 {
  text-align: left;
}
.features23-container7 {
  flex: 1;
  height: auto;
  display: flex;
  align-self: flex-start;
  box-shadow: 2px 2px 4px 0px #d4d4d4;
  align-items: flex-start;
  flex-direction: column;
  justify-content: center;
  background-color: var(--dl-color-theme-accent2);
}
.features23-image5 {
  width: var(--dl-size-size-small);
  height: var(--dl-size-size-small);
  object-fit: cover;
  border-radius: var(--dl-radius-radius-round);
}
.features23-text13 {
  text-align: left;
}
@media(max-width: 991px) {
  .features23-max-width {
    flex-direction: column;
  }
  .features23-container {
    margin-bottom: var(--dl-space-space-threeunits);
  }
}
@media(max-width: 767px) {
  .features23-container {
    margin-bottom: var(--dl-space-space-oneandhalfunits);
  }
  .features23-container2 {
    width: 100%;
  }
  .features23-container3 {
    width: 100%;
  }
  .features23-container4 {
    width: 100%;
  }
  .features23-container5 {
    width: 100%;
  }
  .features23-container6 {
    width: 100%;
  }
  .features23-container7 {
    width: 100%;
  }
}
@media(max-width: 479px) {
  .features23-max-width {
    gap: var(--dl-space-space-oneandhalfunits);
  }
  .features23-button {
    width: 100%;
  }
}
</style>
