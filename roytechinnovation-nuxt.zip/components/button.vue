<template>
  <div class="button-container">
    <button class="thq-button-outline button-button">
      <span class="thq-body-small">{{ text }}</span>
    </button>
  </div>
</template>

<script>
export default {
  name: 'Button',
  props: {
    text: {
      type: String,
      default: 'Contact Us',
    },
  },
}
</script>

<style scoped>
.button-container {
  display: flex;
  position: relative;
}
@media(max-width: 479px) {
  .button-button {
    width: 100%;
  }
}
</style>
