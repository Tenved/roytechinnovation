<template>
  <div class="stats2-container thq-section-padding">
    <div class="stats2-max-width thq-section-max-width">
      <div class="thq-flex-column">
        <img
          :alt="image1Alt"
          :src="image1Src"
          class="thq-img-ratio-1-1 stats2-image"
        />
      </div>
      <div class="stats2-container2 thq-flex-column">
        <span class="thq-body-small">{{ content1 }}</span>
        <h2 class="thq-heading-2">{{ heading1 }}</h2>
        <p class="thq-body-large">{{ content2 }}</p>
        <div class="stats2-container3 thq-grid-2">
          <div class="stats2-container4">
            <h2 class="thq-heading-2">{{ stat1 }}</h2>
            <span class="thq-body-small">{{ stat1Description }}</span>
          </div>
          <div class="stats2-container5">
            <h2 class="thq-heading-2">{{ stat2 }}</h2>
            <span class="thq-body-small">{{ stat2Description }}</span>
          </div>
        </div>
        <div class="stats2-container6 thq-grid-2">
          <div class="stats2-container7">
            <h2 class="thq-heading-2">{{ stat3 }}</h2>
            <span class="thq-body-small">{{ stat3Description }}</span>
          </div>
          <div class="stats2-container8">
            <h2 class="thq-heading-2">{{ stat4 }}</h2>
            <span class="thq-body-small">{{ stat4Description }}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Stats2',
  props: {
    image1Alt: {
      type: String,
      default: 'RoyTechInnovations Stats Image',
    },
    stat1: {
      type: String,
      default: 'Tailored Solutions',
    },
    stat2Description: {
      type: String,
      default: 'Focused on delivering high-quality and efficient solutions',
    },
    stat4: {
      type: String,
      default: 'Quality Assurance',
    },
    stat3Description: {
      type: String,
      default:
        'Dedicated to exceeding customer expectations and ensuring satisfaction',
    },
    stat3: {
      type: String,
      default: 'Customer Satisfaction',
    },
    stat4Description: {
      type: String,
      default: 'Ensuring top-notch quality in all our products and services',
    },
    heading1: {
      type: String,
      default: 'Our Stats',
    },
    stat2: {
      type: String,
      default: 'Cutting-Edge Technology',
    },
    stat1Description: {
      type: String,
      default:
        "Providing personalized services tailored to each client's unique requirements",
    },
    image1Src: {
      type: String,
      default:
        'https://images.unsplash.com/photo-1548100721-15f0e76035c8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTcwMDU5MHw&ixlib=rb-4.0.3&q=80&w=1080',
    },
    content1: {
      type: String,
      default:
        'Customized services and products to meet your specific business needs',
    },
    content2: {
      type: String,
      default:
        'Innovative technology solutions designed for efficiency and effectiveness',
    },
  },
}
</script>

<style scoped>
.stats2-container {
  width: 100%;
  flex-direction: column;
}
.stats2-max-width {
  gap: var(--dl-space-space-twounits);
  flex: 0 0 auto;
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: flex-start;
}
.stats2-container2 {
  align-self: center;
}
.stats2-container3 {
  width: 100%;
}
.stats2-container4 {
  width: 100%;
  height: 100%;
  align-items: flex-start;
}
.stats2-container5 {
  width: 100%;
  height: 100%;
  align-items: flex-start;
}
.stats2-container6 {
  width: 100%;
}
.stats2-container7 {
  width: 100%;
  height: 100%;
  align-items: flex-start;
}
.stats2-container8 {
  width: 100%;
  height: 100%;
  align-items: flex-start;
}
@media(max-width: 991px) {
  .stats2-max-width {
    gap: var(--dl-space-space-twounits);
    flex-direction: column;
  }
}
@media(max-width: 479px) {
  .stats2-image {
    width: 100%;
  }
}
</style>
