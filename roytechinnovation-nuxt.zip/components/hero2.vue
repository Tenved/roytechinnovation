<template>
  <div class="hero2-header5 thq-section-padding">
    <img :alt="image1Alt" :src="image1Src" class="hero2-image" />
    <div class="hero2-container">
      <div class="hero2-max-width thq-section-max-width">
        <div class="hero2-column">
          <div class="hero2-content">
            <h1 class="thq-heading-1 hero2-text">{{ heading1 }}</h1>
            <p class="thq-body-large hero2-text1">{{ content1 }}</p>
            <div class="hero2-actions">
              <div class="hero2-container1">
                <button class="hero2-button thq-button-filled">
                  <span class="thq-body-small">{{ action1 }}</span>
                </button>
              </div>
              <div class="hero2-container2">
                <button class="hero2-button1 thq-button-outline">
                  <span class="thq-body-small">{{ action2 }}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Hero2',
  props: {
    heading1: {
      type: String,
      default: 'Welcome to RoyTechInnovations',
    },
    image1Alt: {
      type: String,
      default: 'Technology Solutions Image',
    },
    content1: {
      type: String,
      default: 'Empowering businesses with cutting-edge technology solutions',
    },
    image1Src: {
      type: String,
      default:
        'https://images.unsplash.com/photo-1627810551083-aeae84ab3dfc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyM3w&ixlib=rb-4.0.3&q=80&w=1080',
    },
    action1: {
      type: String,
      default: 'Learn More',
    },
    action2: {
      type: String,
      default: 'Contact Us',
    },
  },
}
</script>

<style scoped>
.hero2-header5 {
  width: 100%;
  height: 100vh;
  display: flex;
  position: relative;
  align-items: flex-start;
  justify-content: flex-end;
}
.hero2-image {
  top: 0px;
  left: 0px;
  width: 100%;
  height: 100%;
  position: absolute;
  object-fit: cover;
}
.hero2-container {
  width: 100%;
  display: flex;
  align-items: flex-start;
  justify-content: flex-end;
}
.hero2-max-width {
  display: flex;
  align-self: center;
  align-items: center;
  justify-content: flex-start;
}
.hero2-column {
  gap: 24px;
  width: auto;
  display: flex;
  z-index: 1;
  max-width: 560px;
  align-items: flex-start;
  flex-shrink: 0;
  flex-direction: column;
}
.hero2-content {
  gap: 24px;
  display: flex;
  align-self: stretch;
  align-items: flex-start;
  flex-direction: column;
}
.hero2-actions {
  gap: var(--dl-space-space-unit);
  display: flex;
  align-items: flex-start;
}
.hero2-container1 {
  display: flex;
  align-items: flex-start;
}
.hero2-button {
  display: flex;
  box-sizing: content-box;
  align-items: center;
  border-color: var(--dl-color-theme-primary1);
  border-style: solid;
  border-width: 1px;
  justify-content: center;
  background-color: var(--dl-color-theme-primary1);
}
.hero2-container2 {
  display: flex;
  align-items: flex-start;
}
.hero2-button1 {
  gap: var(--dl-space-space-halfunit);
  display: flex;
  box-sizing: content-box;
  align-items: center;
  border-color: var(--dl-color-theme-primary1);
  border-style: solid;
  border-width: 1px;
  justify-content: center;
}
@media(max-width: 767px) {
  .hero2-header5 {
    justify-content: center;
  }
  .hero2-max-width {
    justify-content: center;
  }
  .hero2-column {
    width: 100%;
  }
  .hero2-text {
    text-align: center;
  }
  .hero2-text1 {
    text-align: center;
  }
  .hero2-actions {
    width: 100%;
    align-self: flex-start;
    justify-content: center;
  }
}
@media(max-width: 479px) {
  .hero2-actions {
    flex-direction: column;
  }
  .hero2-container1 {
    width: 100%;
  }
  .hero2-button {
    width: 100%;
  }
  .hero2-container2 {
    width: 100%;
  }
  .hero2-button1 {
    width: 100%;
  }
}
</style>
