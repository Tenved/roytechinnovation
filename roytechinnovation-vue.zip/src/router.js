import Vue from 'vue'
import Router from 'vue-router'
import Meta from 'vue-meta'

import Home from './views/home'
import NotFound1, { NotFound } from './views/not-found'
import AboutUs from './views/about-us'
import Services from './views/services'
import Contact from './views/contact'
import Minecraft from './views/minecraft'
import './style.css'

Vue.use(Router)
Vue.use(Meta)
export default new Router({
  mode: 'history',
  routes: [
    {
      name: 'Home',
      path: '/',
      component: Home,
    },
    {
      name: 'Not-Found',
      path: '/not-found',
      component: NotFound1,
    },
    {
      name: 'About-Us',
      path: '/about-us',
      component: AboutUs,
    },
    {
      name: 'services',
      path: '/services',
      component: Services,
    },
    {
      name: 'contact',
      path: '/contact',
      component: Contact,
    },
    {
      name: 'Minecraft',
      path: '/minecraft',
      component: Minecraft,
    },
    {
      name: '404 - Not Found',
      path: '**',
      component: NotFound,
      fallback: true,
    },
  ],
})
