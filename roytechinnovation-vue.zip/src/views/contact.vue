<template>
  <div class="contact-container">
    <div class="contact-header">
      <header
        data-thq="thq-navbar"
        class="navbarContainer contact-navbar-interactive"
      >
        <span class="logo">ROYTECHINNOVATIONS</span>
        <div data-thq="thq-navbar-nav" class="contact-desktop-menu">
          <nav class="contact-links">
            <router-link to="/" class="contact-nav12 bodySmall">Home</router-link>
            <router-link to="/about-us" class="contact-nav22 bodySmall">
              About Us
            </router-link>
            <router-link to="/services" class="contact-nav32 bodySmall">
              Services
            </router-link>
            <a
              href="https://667ce7c72fc74.site123.me"
              target="_blank"
              rel="noreferrer noopener"
              class="contact-nav42"
            >
              Minecraft
            </a>
            <router-link to="/contact" class="contact-nav52 bodySmall">
              Contact
            </router-link>
          </nav>
          <div class="contact-buttons"></div>
        </div>
        <div data-thq="thq-burger-menu" class="contact-burger-menu">
          <svg viewBox="0 0 1024 1024" class="contact-icon socialIcons">
            <path
              d="M128 554.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 298.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 810.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"
            ></path>
          </svg>
        </div>
        <div data-thq="thq-mobile-menu" class="contact-mobile-menu1 mobileMenu">
          <div class="contact-nav">
            <div class="contact-top">
              <span class="logo">ROYTECHINNOVATIONS</span>
              <div data-thq="thq-close-menu" class="contact-close-menu">
                <svg viewBox="0 0 1024 1024" class="contact-icon02 socialIcons">
                  <path
                    d="M810 274l-238 238 238 238-60 60-238-238-238 238-60-60 238-238-238-238 60-60 238 238 238-238z"
                  ></path>
                </svg>
              </div>
            </div>
            <nav class="contact-links1">
              <span class="contact-nav121 bodySmall">Home</span>
              <span class="contact-nav221 bodySmall">About Us</span>
              <span class="contact-nav321 bodySmall">Services</span>
              <span class="contact-nav421 bodySmall">Products</span>
              <span class="contact-nav521 bodySmall">Contact</span>
            </nav>
            <div class="contact-buttons1">
              <button class="buttonFlat">Login</button>
              <button class="buttonFilled">Register</button>
            </div>
          </div>
          <div>
            <svg
              viewBox="0 0 950.8571428571428 1024"
              class="contact-icon04 socialIcons"
            >
              <path
                d="M925.714 233.143c-25.143 36.571-56.571 69.143-92.571 95.429 0.571 8 0.571 16 0.571 24 0 244-185.714 525.143-525.143 525.143-104.571 0-201.714-30.286-283.429-82.857 14.857 1.714 29.143 2.286 44.571 2.286 86.286 0 165.714-29.143 229.143-78.857-81.143-1.714-149.143-54.857-172.571-128 11.429 1.714 22.857 2.857 34.857 2.857 16.571 0 33.143-2.286 48.571-6.286-84.571-17.143-148-91.429-148-181.143v-2.286c24.571 13.714 53.143 22.286 83.429 23.429-49.714-33.143-82.286-89.714-82.286-153.714 0-34.286 9.143-65.714 25.143-93.143 90.857 112 227.429 185.143 380.571 193.143-2.857-13.714-4.571-28-4.571-42.286 0-101.714 82.286-184.571 184.571-184.571 53.143 0 101.143 22.286 134.857 58.286 41.714-8 81.714-23.429 117.143-44.571-13.714 42.857-42.857 78.857-81.143 101.714 37.143-4 73.143-14.286 106.286-28.571z"
              ></path></svg
            ><svg
              viewBox="0 0 877.7142857142857 1024"
              class="contact-icon06 socialIcons"
            >
              <path
                d="M585.143 512c0-80.571-65.714-146.286-146.286-146.286s-146.286 65.714-146.286 146.286 65.714 146.286 146.286 146.286 146.286-65.714 146.286-146.286zM664 512c0 124.571-100.571 225.143-225.143 225.143s-225.143-100.571-225.143-225.143 100.571-225.143 225.143-225.143 225.143 100.571 225.143 225.143zM725.714 277.714c0 29.143-23.429 52.571-52.571 52.571s-52.571-23.429-52.571-52.571 23.429-52.571 52.571-52.571 52.571 23.429 52.571 52.571zM438.857 152c-64 0-201.143-5.143-258.857 17.714-20 8-34.857 17.714-50.286 33.143s-25.143 30.286-33.143 50.286c-22.857 57.714-17.714 194.857-17.714 258.857s-5.143 201.143 17.714 258.857c8 20 17.714 34.857 33.143 50.286s30.286 25.143 50.286 33.143c57.714 22.857 194.857 17.714 258.857 17.714s201.143 5.143 258.857-17.714c20-8 34.857-17.714 50.286-33.143s25.143-30.286 33.143-50.286c22.857-57.714 17.714-194.857 17.714-258.857s5.143-201.143-17.714-258.857c-8-20-17.714-34.857-33.143-50.286s-30.286-25.143-50.286-33.143c-57.714-22.857-194.857-17.714-258.857-17.714zM877.714 512c0 60.571 0.571 120.571-2.857 181.143-3.429 70.286-19.429 132.571-70.857 184s-113.714 67.429-184 70.857c-60.571 3.429-120.571 2.857-181.143 2.857s-120.571 0.571-181.143-2.857c-70.286-3.429-132.571-19.429-184-70.857s-67.429-113.714-70.857-184c-3.429-60.571-2.857-120.571-2.857-181.143s-0.571-120.571 2.857-181.143c3.429-70.286 19.429-132.571 70.857-184s113.714-67.429 184-70.857c60.571-3.429 120.571-2.857 181.143-2.857s120.571-0.571 181.143 2.857c70.286 3.429 132.571 19.429 184 70.857s67.429 113.714 70.857 184c3.429 60.571 2.857 120.571 2.857 181.143z"
              ></path></svg
            ><svg
              viewBox="0 0 602.2582857142856 1024"
              class="contact-icon08 socialIcons"
            >
              <path
                d="M548 6.857v150.857h-89.714c-70.286 0-83.429 33.714-83.429 82.286v108h167.429l-22.286 169.143h-145.143v433.714h-174.857v-433.714h-145.714v-169.143h145.714v-124.571c0-144.571 88.571-223.429 217.714-223.429 61.714 0 114.857 4.571 130.286 6.857z"
              ></path>
            </svg>
          </div>
        </div>
      </header>
    </div>
    <div class="contact-contactform2">
      <div class="contact-contact9 thq-section-padding">
        <div class="thq-flex-row thq-section-max-width contact-max-width">
          <img
            alt="Image1"
            src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxIQEBUQERAVFRUVEhYXFRUVFRcWFRcXFxYXFxcWGBUYHSggGRslGxUVITEhJSkrLi4uGB8zODMtNygtLisBCgoKDg0OGxAQGy0mICUtLS0vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSstLS0tLS0tLS0tLS0tLS0tLS0rLS0vL//AABEIALEBHAMBEQACEQEDEQH/xAAbAAADAQEBAQEAAAAAAAAAAAAAAQIFBAMGB//EAEAQAAEDAgQEBAMFBQcEAwAAAAEAAhEDIQQSMUEFIlFhE3GBkTKh8EJSscHhBmJygvEUIzOSssLRJGOTohU0g//EABoBAQEBAQEBAQAAAAAAAAAAAAABAwIEBQb/xAA5EQACAQIDBQcDAgUDBQAAAAAAAQIDESExQQQSUXHwImGBkaGxwRMy0eHxI0JSYpIzQ4IFFCSiwv/aAAwDAQACEQMRAD8A/FFsZggBACAEAIAQAgBACAEAIAQAgGgBACAEICFBACASAEAIAQAgBACAEAIAQAgBACAEAIAQAgBACAEA0AIBIAQAgGgBCAqAUAKgEBQYUsTeR6twjzYMcfIFXdZm60Fm0FXBvZdzHN/iBH4quLWYjWhL7WmeJauTS4kKCAEAKAEKJACAEAIAQAgGgEgBANACAEAkAIAQAgBACAEA0ICoBACAcIAhAelGiXkNaCSTAAEkk6AAalVK+COJzUVdn0GH4RRo3xDi5wEmmwgAW0dU3Olm/wCZbqEY/cfMntdWrhRVlxfwtPHyNKlj2sANBlNpiYZ8Qto52XM6B1m+67VS32nkls8pO1Vtrvy8Fey9Diq8argwarrd/wAPRcOrPieiOxULXUUeuF45UAJL3mbTLiABExzAdNdvNI1ZcTmpsVN4KK68DzdVoV7VKABOjqQDHTuTAyn1b6q70ZZryKoVqOMJ4cJYr8+pm8W4IaQ8Rjs9OYmIc07B7fszBgyQYWc6VsVkevZttVR7slaXo+T1MeFke4IQokAIAUAIBIUEAIAQAgBACAEAIAQAgBACAcWn+qpL4iUKNCAqAQDhACEGgBANrZVI3Y+no0hhKe3jmz/+2N6Y77OPct6z6P8ATXefHlJ7VO/8iy7+/lw8+Fs7EYgOJN7kwJ06X3WTdz1wpuKSOd1UQba9dv1+rrm5qosguJME3mNbe/5odWSQNqHT6/XRA4rM96NfKZ1tv3EEb7SPY9lU7Gc4bysbGH4kXPMkuDhl5pIeLcr2zeQItf5RrGeJ4amz9lcfVd6fd5Gbx7hQpRUp3pu03LHRPhuPWNOonoVzUp2xWR6dj2p1Lwn9y9VxXXujGWJ9AEAoQBCFEgBACgEhQQAgBACAEAIAQAgBACAaAFSAgGgGhAQAgHCEBUG5+zFBviGs8gNpwRMxnJhlhcxDnW+4tqSSe89D5+3zk4qlHOXtr8LxFxGtzyNd9TfMdZ30XM3iKEOzbrIzn+e8Rv8AX10XB60RUBBg/Ig/MKFi01dEl3y/r+aHViqOYuDWzJMADU3n8p9FVfQ5lupXlkaWF4Q913OawXkuM6a6W3G+phaRpt5nkqbXCP2ps0WcIYwZnViOTMBk2ykmxcbwJ21t27+klqeV7ZOTsoa2z7+S1w9x8KqMqMdRebPETYFoF2u/eg31nljQlKbTwY2mMoNVIrFY/ld18v1R81iqBY9zHatcQfMGD8wsJKzsfWpzU4qSyeJ4wuTsSFBACASFEgBAMICVCggBACAEAIAQAgGhAVA0AIQaAaAIQg4VAIQaA+m4NR/6U8uYvrZQ28uLWAtAjW9RwPmvRBdjxPkbTJvaUk8o+7x9lYxqkdT3tp1gTffposT6EbmlW/Z50Zm1mOkgS4OaCXXAm9/rdaui9GeOP/UI3s4NcrPLyMrFYKpT+JtvvC7b6X29VlKDWZ7adeFT7X4anOATYCSdANSei5Ncsz6GjhBh2uvL/DHMLXecuXMQYjMHC0mATtHoUdxd58qdV12v6b5csb2w4WeOGXG/ZSo8l23dSy5SwujmcZkAtJMzlNua8LtLDwPPKfbweCd73touTwyv3YXOfiuLcGFpc4l4a3mytHVxyj0EnYjTficnY22alFzukrK7wu+WP41Ry4DDkOGchrRJJuY7y0HeN/JcRXE9FWaatHPrj+Dl/aNv/U1DES8uj+LmP4qVfvZpsD/gR5W8sDLWZ7AhCiUAIUSASAIEd59IQaiQoKASFBACAEAIAQDQgKgpqEYIAQDQg4VAwEJcIQDhACEPoMO6cCR0rEeQLWGfdpHqt/8Ab8T5k1ba+cfZv8+hl16RaQHQJAJ3gEA3A3g6LJo9sXdXRvcGxJqUwJMsygtk3a2blsHNYDabdl6Kcro+XtdNQm3o749778LdcS6rhmIbBltRrmnUO56kOaYt/KZE21Krzw7/AMnMU7drRpp92Cwz91jbkZf9hDMQ0snIW+I2RJFjAjch2U/8wstxKWGR7frudBqWd7PrvVzSYyX1TkPxlgYwkB2UktDhHKAGgGLGQLyFpbF4HjcrRgr6Xu9L4O2OLxw8csTyqPDeYhpdy81R2c6EEnLygXMSJkEdFG7Y+53GLl2Ve2OSt748/BmPicV4r8zgY0iYMSfSbjbYLGUrs+hTpfTjZHTw2gfEZabg9YGpmNLFp/mCsFijGvNbkuuv0PL9oY/tDwDMEN9WtDT8wUq/czvYb/Ri3rj5u5mwsz2ChACAUIUSgEhQQChCiQAoBIUEAIAQDQgKgpCAgGhBwqAQg0A0INAEKgcIQ3f2aqB2ei4DnALZ+8wOt7OJ7loG62pO94nzdvi1aotMHydv28W9DhxzYcRO4BF4JDQJkmTedeqzlmemi7xT6zPBlTIQW3tcGYPUWjzUTsayjvKzN7CcRp1BdzgYg0y4ZXT90OsTIB2g3jY+iM0z5dXZ6kHglztiudunkefEx4dSiz4jBH8THta2SCPPWfh9BJ4NI72d/UhOWS9mm31a2fi5xnGKZdy5soEBrWgDlBDdTFzedRFlJVFfAtLZJpY58W+OenplxMiviTUs4kADlFze+pJubm//ACVk5XPfCmoYrN9dIikAbHewPQyL+0rk6kb3CajiTUfAptPiuaBEwIAA7zlB7xpK3p53Z83abKKpwvd4X64Z+pgYqqXvc46uJJ8yZKxk7u59KnFQiorQ8YUNBtbJi3qYHuoS5KFEhRIAhCiUAkKJADvKLfRQqEoAI9e6pUJQDVICArbTzP6IQEA0INUDQhUToNBf8J9yhze2YkKNUg4QDQgwgLovLXBwJBBBBFiCNweqqdjmUVJWZucRPjU212NgmW1A1ujhBm2xF/UjQLafaW8j51D+DN0pPDNX4fpl66mZi6bWgNAk3Jfe40AAO0tcZi8gzsMmrHspzcrtnKLHSe39Fyas7sJUik8uuWR4Z3aXWMeXKY81pF9lnnqR/iJLXPvt0zhb3CzPSwAQHbhKbJyuDi6YiIAOw+Ia6SevZdxS1PPVlO145ddx38cqtpsFBgyyc7wJgTdjLkkwDN51aNWrSpaK3UeXZIyqTdWXJfL+PPiYKwPpiQAW2n69vX8eiFBtjJEjcde0hCPLAkqHQoQXEhRIUSgAhComEAEIUSgEhRqkGEINANCDCoGhBoQaArKYmLTE7T0lUlzT4XhG1Gw97mBzw1pa34j3cbEC5jsbrSEU8zx7RWlCXZSdld3enLicWKw7qVR1N45mOLXDu0wVw1Z2PRCanFSWTxPKFDocKgcIQ2/2YqtNQ0ahIZVGU5YJB+yQDqdW/wA61pP+XieDboPdVRZxd/DX8+ByYppc+MvN8JBuZFt+gt6BcSxZtTaUL3wPDFYR1M5XRMA2IIvtItI3UaaNYVIzV0e9VsYdoH2nyfYgD2g+vddP7DGLvXfcjjybrg9Fz0AJgfkBEnr081Tm6WJqcKIAfUeAWsBdEWLiWhrY0ubaWBcdlpT1bPHtN3aEXi8PDG78M+dkY+Jql7i5xkkkk9STJPus27u57qcVCKiskeSh2KFANoE3MekoG3oaGB4c2pSNZ5LW5xTbkAJL8oNx6t01LtlpGCauzzVtolCahBXdru/Dq/JLU4MQzK4sIu0kEwQTexIOloXDVnY9EJby3uJ5KHYlCiQokKJQCQoOMmbDy09ECwJQo3NjXpPodECd8gCAaEGEIMKgaEGhBhANUhdOmXODRqTHvuiVzmUlFXehu1cpp1Wg/ACQ3swsDXTpY5xboJ1vvoz50bqUJcXj4398DVr4ZlWs+lUygHTlObMWBxuNCDUaVtKKcmmeGnUnTpKpC/xa9vhnyDmQSDqCQfReM+6ndXEhQhCHvhKhY9r26tII8wZC6i7O5xUipxcXkz6TjVIMcXsaOa7CNcrs0E9DGnYg9J2qWTuj5WyScoqMnz5q3zn+5mvYzIAbgEXbvExykTu7cTrtAzwsepOW82tes/LiTiGZmMbNxAuQIlo67a+SPFJFg7TlLrM5qFAkgAgHaZ16CBquUjaU7I96uDdTs6x03GmrTIFwYVcbGaqqWR08Tc5mFp0zPM5zoP3W/DbpmfVK7lhBIxoWnXlLgkvPP2RgwsT6IIUciZyja14PzlAa37P4RjhUqVIAYBlLgSA4yZga2HTfstaUVi2eHbas04whre/I7qrMwpAgM/8AsOLhADXMpwHX3GUeXoI0aul4nmi91ztj9itxTeXjcyuJCR4jTMPeyQI5DGWxuLdd3lYyyue6jZS3HwT8deuCRlQsz2CQBlMTFtJULdXsShRFCiKgEhRIUSAoIQYQDCpCotredP1Q51BAMKkGgKAQh3cMpznIbcU3ZXSRBcMm3ZxPotILM820Stu3eF1hyx+PU1sK1obXfHLAF5Doz02nylwdPmCtYpWbPDUb3qcdfTJv2sabgDinRIzGmQ0bTTbOpn7Mey1f+p5ex5L/APjruv7v83MDi+AyuqVGk2rPD2n4mnMYPcH5W6289SFm2uJ9PZa+9GMJaxVno8Pf9eBmkyZNydSsj1jaYMwD5qhiCA+r4HVbXp+G4Bz2NIDTq5sHLAm5aZ9MvQr0w7asfF2qLoT31k/R6+fvfidbuEOPL4RAiM0ED4tTlbJ9BOtrQq6b4GMdrje+8ulzOOrwKoTIpmBrY38tToOmq5dJ8DeO3QSs5ex5s4HVJjw3Dzb9T9eS5+lLgdvbqSV95eZqs4a5pMgRJBcWwOuYFwEHbNaAtVTZ43tMdH11jY+X49ixUqcnwsGVvcAkk+pJPlCwqSu8D62x0nTh2s3i+uXqZayPYM7W/W+v4D0VBWHpOe4MaAS6wn8Z2016SiV3Yk5qMd55I+lwOFbToPDSXf32Uu+FriGi3YXPXdeqMUoO3E+PWqynWi5K3ZvbNrH3LpGadBoGZzxioJtMsqgyCY1A2m+qqxUVz+SSwnUbwS3PeJktoy1zAJOWoI7nK+n88vuFhbQ9rnaSk+K+U/kxSFifREUKSUAlCiQoEmIm0zHdBbG5Kh0JAJwj9ECYwgGFSFIQcIQpsb9PmqR3GAhGxhANUhq4FkUCRq5zgO5ZTPLO0+L7AjdaxXZ661PFVleqlwS9Wsf/AF9bmgzlo18z5flaC102JrSTexFo9PfRYRlfrE8r7VWnZYXeP/Gx0YusW1KTjIdkYc4OYNjO0ze5EA67JJ4o4p006ckuOXk/DgepJdiqoeRlq081xmEuZBkAfFLDt1Xb+995nFJbPHdzi7eT9sT5RzC0lpsQSCOhBgheSx9pSTV0KEA4QGhwPN4stIENebkAfCdytKd74Hl2u308eK9z3fWr7VWj/wDakP8AcrefH1RmoUdYv/GX4J8XEb1af/no/wC18+gS8+Pqi7lD+l/4y+UddN5BvjWwBchwJdfSL6d5XSb/AKjCUU1hSfll7HrjMY1+HeA8GAOYNIkyOU2G2/5KyleLOKVFwrRuvC68z5uN/r29F5z6xKFHbpsetzeD6SPZAbH7O0RFSo7lhuQOMkS8gQIGoA/9ltSWDZ4dtk7xguduXx+DqGIc3CMa4nnc6q5o1OZ/xTsYjrZ/v03amvMwUFLaZNaWj5LL38jopuHi4ewDfDefiuMzKlj0InXuF3F9qJnOP8OpxuvRr8GTTcWEPDszRobw5zPCytAd1ho7EzaFisHfrQ9kkpJxas36J7127cOszM4hQ8Oq+n917mjyBICzmrSaPZQnv04z4pM5iuDYRQoiLfkgJKhRIUkoUShRICghBhUgwgKQgwqQYQhQVIMIQ3cK1hwjM2gxDy6NQCxgOvxCA4xa03W6t9Ncz503JbS7axXu/kipUyF4nNnAAm4dkfmvF78tptm1spe1zpRUrNYW9Lq3XLLE7zhqj3kE8wEa2tIIB7QW+mtjHe62zy/Upwhhl1n7npjaRDaVUOOZhyuNw4XMN66A/wCZdSWCZxRmt6dNrB493PrgZnGMMW1y4Q0VG5xPw8zTnEnW+b3CyqRtLme3ZKidG2e7h34ZehmQsj1lHXSOwmB2uqQ7eDNJrNAbMyDroWkONugJPou6f3Hn2ppUm27fm+B14ig/4Rg5hxi1Z3TSHBdNP+n3MIVIWu6vrFfBRp19BgqQ7mlPqS4ke6tpf0ryJvUc/qy/y/CB2HqtMuNBokGMuGa7TYlgA9SlpLO3oFUpyVlvPxm17v2PbGB4o1M1djhygAZSdbt5RE+XQ6Ku+67szpbrqxtBrPj544nz4asD6lyYUKKEKb39kd4FKmBBqHORe+YjKD1EBq9G72UuJ8z60fqym8d3Dyz+Tvx2Hc4hrCMlNoAtIGhyxfNEBdyV8jy0aijjLNvp9xm1Kzqfhud8LcwadXA5dB0BDs2+mvXO7Vmz2RhGpvRWbtyz+LW05HM2jLWteebMwBgAHKAM0mbGfCEbm8hcJZXN3JK7j349ePgcvHDOJrH/ALr/APUVKv3vma7GrUIcl7HAsz0klQooQolCiKFJQoATZBckhQqZTddJ7f0VOWMICgEIMKkGhCghBhUgwhDV4cQ6hVok/dqC4A5JDhJ05XZp6MK2hjBx8Tx1041YVF3rzy9VbxDFOytBykOBpuAN2nlkmRuT2v5AKSFNXbV8MV35/jy8zbqYvwqza7H5W1KZIsTZ1OSIjcT6+S2k7S3j58Ke/SdNrFO3rbruNfAMZXZL+lyPtAQQfMSAVrG0lifPrOdGXZ/b9zn4pwrx6QYBzt/w+8C7fMwD5xopOnvRsbbPtTp1N55PP4Z8U9hBgiCF4rWP0KkmroA209/X6sgudfDSGV2ZrQ68Hfz6Tr2XcMJYmG0XnSe7wO2tggH82Hq6mQ0iPSGaarrdxyfXgYRrNxwnHx/cbeHAgtbga5uLkhpHaTSNrfMqqH9r68Dl7TZputH3/wDo96GDImcHlj75DzvpDAT7wqo/2mc61/8Advyw+WHE6RFB0in8TfhEREzBJvqNLXO6TXZ0Ls8k6ytfJ59dcj56FgfTAj9ff/iEKavAeGmu4l3+G2C6TAmbDzNx6la0qe88cjxbZtP0o9n7nkfYDDNeS50jKDltYa3Py9gF692+J8B1ZRSjHXMx+KcRyNqU2uygty5YmW5xYkCZLrrGcrYH0NmoOTU2r9/hf0MnizwxtCmeYznfaZElotvIDrdgs6mCSPZsyc3UmsNF7kYRgFZlRwcGtzVSSRcNN7RvDW66u6lSP3Jvmd1W3SlBWu7R8/xi+S4GNXeXOLjqSSfVYyxdz3wSjFJHmD2UOySoUlCiKFJKhRIURQpKhSgqQsC2t50/VDnUAqQsNtr1nbp7oRsAgKCpBoQoIQ9sLXNNzXgTlMwdCN2nsRIPYrqLs7mVSCnFxevV/DM06+FOZzqT/sZwS4CaRMB02uLNIixBGxK0lHHDpHlp1LxSmsnb/lw+VjisTr4ZS/tFL+zNu+m7Mz95rnQYHYu/9yu4dqO7wMK7dKqquksHz08/g9uA4zK90OAa0SJNiZiD5gnWLAdFacrMz2yipQV1i+uu8+textSmHMN7aL15q6PgpyhPdkfOftBwgVAKrC0PIJLRvGx6OgT3Xnqw3sVmfY2LanT7Evt48P0PliyJBkEbRv8AkvLY+zvXxQoQtzYw2ObUY2nWc5pbZtQEkEbNeBeO4v8AitVJSVmfPnQlTk500mnmvlfhnljuG1ARIzB3wuF2nvItvqLWXMoNGlHaYNO2Fs+P5Ov/AONp0wKlYZIaOSeZxiwDSCY0E6arv6aWMjD/ALmc24Uscc9F4r9zM4jjXVnAkQ1tmMGjR+Z6nf2AznJyPZQoxpLDFvN8euBxkLg3OzhmAdVdazRq4iR0gA6m67hByZhtG0RpLv4H3OCwIZlpsIyANnKQZJEmTu68fJe6MdFkfm69ZyvOWbJ4vimtmmxwacpN98oJDbDcqVJWwRdlpOfbll1ifL8Mwwrk1HWbTvUMyLnNnJm1mE+h6rzQSk7s+1tE5UY7sVnl7W8b9WM+pWfiKz3g5Q6TBMAU2iYN9mt9x3Wbk5SbPVCnGjSjB4293+WLFkU6LWA3qEOvE+GLt0mM7+aJPwMO8I+zG3H2/UU71Kjk9MPHX/FYZataGbAg3vOn6+3usz143IhQtxEd0LckqHQihSSoURQpKAShSgqQoHt+ndCMYVIMIQpUhU2j6+rIcjCA9LCwvfXt5KnOIAIDS4ViwP7p5EGcpOjS6Ja47U3QJ6EA9Z1py0fX6M8e00m+3HPXvtqv7lpxxXA9W58NWa8z/d2yu1c0uLXM9iZ6Kq8JX4HL3NopOK/m1WjtdPzOriWB8Ml1MzSeAaZH2s0mOxs3yFl3UhbFZMw2ev8AUW7P7ln3W6+TS4FxHww0ZwZLuT7MWmSPLXsu6c7Hk2zZ99t2ytjqaOMoCoM9OL/ZdvF/iH5laNXxR46U3B7s/Nfgwq9MPPh1wWvHwvgl56Az8Q9d7brBq+Ej6kJuK36WK1Wn6HBiMA6k/I8QfkfrouHCzsz0wrqpHeidOFwbHaldRimYVK0lkfRcO4exgOTEhgO35xpPdeiEEsmfKr7RKT7VO5mY/hlMEnxMxOpm57rKUFxPZR2qbVt2xkV8MBcadfryKyaPfCo2etHhga0Vatmn4RcZvMjQXHcj0mqFldnE9pbk4U89Xw5cfY1MDSfVObKGM0baA0CbNA89hC1imzx15whhe71733mricY2hTLWm8XduJ+60fX5aOSijw06Mq0035flny+NPiVTL80mJi5DjofMGJ/4XmljI+1SW5TWFv0HjKfgUBRJAq1wHVCbQxskA9C4i/8ACeq6mtyO7q8yUpfWquosYwwXN/he64HPh6Qo0zUqCxGUMNi+wJYf3TMuOwAGpC4it1XfXWprOTqz3IPvvw7+fDvvomZNeq57i9xlzjJP1oNo2Cybbd2e2EVCKjHJHmVDsShSSfkgRKHRJUKKO/6oW5KhRIUSFGEIUhBhUhQQhQVIMIclBCFBUhQCEKhUhrYOqMQ1tGo6Hi1Jx0Owpu+UHsB0jaLU1uvPQ8NWLoN1ILB5r5XyvHid/D7sfhKggtdmpg6hwkuZ+Lh/MtIZOmzzV8JLaIa4Plo/h+BnAZSbEuzENb2EC1jJsI8ljkev7kuFs+9mtQxwOk3kmwuSXAQReIAJK2UzwzoW665I6MRjGvGSqMxBgOH2co2d007ea7c01aRjCjKD3oYd3G/d14HE/mPhvdmDiSypq4Gw9dpHSeyzfBnpXZ7cVZrNde/HxMupVeHEO1BIPmPJZNu57Iwi4q2QDFO6pvMfSiD8QTefSekJcKmj3wLBBqvuG2A2Lom/YaxuSB1XUVqzOq8VTjm/b9fTFmnSr/arc3MX+EPhbMG41Prp+GqaWMvI8coP7aWGFr8evX3962PLhJdpLQOlwYI6HSf1Vc7mUaCTsl39d/XAzMTiQ5waGuI1I0I5Rm0kzt6eaycrnthScU3ddPAfCKLATVfOWm6QY1Ey0D94l1u7va00vuehNqnJpU45yX7+CtjyPHw/FL8VXMNzkGNSYGWnT62tPQSpbevOXXI73vpbtCksbeXFv354Gbj8W6s7MbACGt2a3YDr57lZTk5O57KNJUo2Xi+LOUhcGxJQpJUKSUKIodElQpJQolCklCiQpQQgwqclBCFBCDCpC7QPmqcjCAqEOSggKywqc3PQtEWmJ1Pytsdd1Tm+Jr0sT44bTe+KgAyVMxg6EBx++NndYB6jZS38G8eJ4JU/o3nBdnVfjueq4ZcB4pzapioBTrNscxim+CZMiMrpnW3caBK0s8GKalSXYxg8cM1+V6+5JzSAWtZkbds31JDoLjJuDtoPNTE6bi1dY316WHD9Toq4vxWNbkptyANsRzakF0HXUe3ddXujJUtyTd3ic9OoCC0ucNHAzmEt2aOsTv8AguUzRxd00lw4Z8SeIw4MqbloD/4gAQfUEf5Sk8bM6odluHDLl+nycMLM9FwhBc1azgwtZMMptk6czwbmDrzGfJbN2w4HiinJOWsvRft6nnQOYyI1nndLpJ2NvfzXKxOp9lW9lgemMxnjmzabIZAggSG7m+sT7+9ct4lOl9LO78H115eDqeYNfUDGNgDNJJeBu1ocZdtIEde/Nr4s13917sLt8OHNvJdJHQ6q17A6HU6NMgNuM73ZSJgfbiIvABJvee7prgkYKMoTtg5yz4JX9vVuywMviGNdVImzWiGNGjR+ZO53WU5uR7aFCNJYZvN8etEcZXB6CSoUkoESUOiSoUkoURUKhSTb2H15D2QuGZBQoiodCQDlCFTp2VJYoIRjCpCghCgFTlspCFNQhQVIUEIMKkKhCGnQcKw5rva2SDPOGjX+IDXqADsZ1XazzPHNOk+zk/S/w9ODw1RzNe5hyn7J0O3WOnpquLtGzjGWK1KpVsrmuyixBLbwY1mDN+x3tCXI43TTLDcwkkkC1otJMADznorY5vbBZnfXZNB4i7XACfiGRx162eRpsNlo12WeaMv4se9eGP7GW1t/o/JZHsudHDG/3zJGhn2E/kuofcjLaH/Clbq57YymCQLl2ggwDlDR01N7+cwrJHFObSvkv3OU1AGltrxfVwieWQYgyOunnPJsld3PLxImwvrIn5aKXO9257YSiXkvebATmdJECJ8+kdwAuoq+LM6k1BKMfJHPiq+eAJyts0G57uP7x1PoNAFzKVzSnT3cXm8+uC0/LZzx3+uq5NSSodIkoUkqFJKFJKh0SUKiShRfQUKSUKSoUSFGEIUFSFBCFBUgwhCghyUFSFgIQoKkGEIWwxp3+Yg/JU5ZXkhyelF+VwcNjKqdmczW8mjvxDGugssHXE6iYLrzcBxInstGk8jzU3Jfdp0vTE42jtOy4N2e1CqabgYBLXaG46QRuFU7HEoqa5mm/E5zU/fD3QBAaYIAaOhJ/DzWt73PJ9Pd3e63jj11gZELI9p18MdlcXRMNt55m/quoYMw2hb0Uu/4Z618UTSFINzBzicxHOYAsHdNLdQq3hY5hTSnvPC2nmZ1QyZiPrVZs9UVZWEynO8fX9USDlY6Me4NGRu93GI0s1oHSGh3eQdl1LDBGVFNvefh8v47sUcIcRodo9DquD02TzPMqHQnf1UKiCh0SVCinshSCoUQE/UIW5BQ6EVCklCkqFEhRhCFBUhQQhbW79FTlsAhCwhBhUhYQhQVIXFlTkYQhQVOSwhDog5BfQ2vNiB7Xj3K60Mv5+ZAOvdQ6KGmipDowb4eO9vwt8l1F4mVVXic65NDowzy1ryOgHe8rpOyZlUjvSSZzFcmxJChQiTAsD9SgyV2LEul7j3MeQsPlCSzLTVoo8SodklQ6EW/P+iFuQVDokqFJKFJJ7IVEh0GQoW11YREbeSFIKh0SUKJxvpHb+qgWQxl3me0K4B72hKhSlSFBCDCpCwhyUFSFBCFBCFBU5LCpGMIQsKnJQQh6j4P5vyK60M/5vAAoU92f4bv42f6Xq6HD+7ruJo/EPNVZklkyFDo9GaH0/NU5eaPMqHRJUOgZq3zH4oHkzzfqh0iCodEFQ6JQpJUKSVDokoUkoUkqFCpt5fmUYjqFfUfwt/0hGIZeL9zxKhoJQpJQp//2Q=="
            class="contact-image1 thq-img-ratio-4-3"
          />
          <div class="contact-content thq-flex-column">
            <div class="contact-section-title thq-card">
              <span class="thq-body-small">Get in touch with us</span>
              <div class="contact-content1">
                <h2 class="thq-heading-2">Contact us</h2>
                <span class="thq-body-small">
                  Our gmail roytechinnovation@gmail,com
                </span>
              </div>
            </div>
            <form class="thq-card">
              <div class="contact-input">
                <label for="contact-form-3-name" class="thq-body-small">
                  Name
                </label>
                <input
                  type="text"
                  id="contact-form-3-name"
                  placeholder="Name"
                  class="thq-input"
                />
              </div>
              <div class="contact-input1">
                <label for="contact-form-3-email" class="thq-body-small">
                  Email
                </label>
                <input
                  type="email"
                  id="contact-form-3-email"
                  required="true"
                  placeholder="Email"
                  class="thq-input"
                />
              </div>
              <div class="contact-container1">
                <label for="contact-form-3-message" class="thq-body-small">
                  Message
                </label>
                <textarea
                  id="contact-form-3-message"
                  rows="3"
                  placeholder="Enter your message"
                  class="thq-input"
                ></textarea>
              </div>
              <div class="contact-checkbox">
                <input
                  type="checkbox"
                  id="contact-form-3-check"
                  checked="true"
                  required="true"
                  class="thq-checkbox"
                />
                <label
                  for="contact-form-3-check"
                  class="contact-text6 thq-body-small"
                >
                  I accept the Terms
                </label>
              </div>
              <a
                href="https://mail.google.com/mail/u/0/#inbox?compose=new"
                target="_blank"
                rel="noreferrer noopener"
                class="contact-button thq-button-filled"
              >
                <span class="thq-body-small">Sumbit</span>
              </a>
            </form>
          </div>
        </div>
      </div>
    </div>
    <div class="contact-contact3">
      <app-contact14
        email1="roytechinnovation@gmail.com"
        phone1="91 9354454315"
        address1="Sector 1, Vaishali(GZB), U.P., INDIA"
        content2="We're here to assist you every step of the way. Whether you have questions about our services, want to discuss a potential collaboration, or simply want to say hello, we'd love to hear from you. Don't hesitate to reach out and get in touch with our team today!"
        content3="Feel free to give us a call to speak directly with a member of our team. We're here to answer any questions you may have and provide assistance."
        content4="Visit us at our office location during business hours to discuss your requirements in person. Our friendly team is ready to assist you with any inquiries or projects you have in mind."
      ></app-contact14>
    </div>
    <div class="contact-contact4">
      <app-contact7
        location1Description="Sector 1, Vaishali(GZB), U.P., INDIA"
        location2Description="S1, PLOT 424, U.P., INDIA"
      ></app-contact7>
    </div>
    <div class="contact-footer">
      <footer class="footerContainer contact-footer1">
        <div class="contact-container2">
          <span class="logo">ROYTECHINNOVATIONS</span>
          <nav class="contact-nav1">
            <router-link to="/" class="contact-nav122 bodySmall">
              Home
            </router-link>
            <router-link to="/about-us" class="contact-nav222 bodySmall">
              About Us
            </router-link>
            <router-link to="/services" class="contact-nav322 bodySmall">
              Services
            </router-link>
            <a
              href="https://667ce7c72fc74.site123.me"
              target="_blank"
              rel="noreferrer noopener"
              class="contact-nav422"
            >
              Minecraft
            </a>
            <router-link to="/contact" class="contact-nav522 bodySmall">
              Contact
            </router-link>
          </nav>
        </div>
        <div class="contact-separator"></div>
        <div class="contact-container3">
          <div class="contact-icon-group1">
            <svg
              viewBox="0 0 950.8571428571428 1024"
              class="contact-icon10 socialIcons"
            >
              <path
                d="M925.714 233.143c-25.143 36.571-56.571 69.143-92.571 95.429 0.571 8 0.571 16 0.571 24 0 244-185.714 525.143-525.143 525.143-104.571 0-201.714-30.286-283.429-82.857 14.857 1.714 29.143 2.286 44.571 2.286 86.286 0 165.714-29.143 229.143-78.857-81.143-1.714-149.143-54.857-172.571-128 11.429 1.714 22.857 2.857 34.857 2.857 16.571 0 33.143-2.286 48.571-6.286-84.571-17.143-148-91.429-148-181.143v-2.286c24.571 13.714 53.143 22.286 83.429 23.429-49.714-33.143-82.286-89.714-82.286-153.714 0-34.286 9.143-65.714 25.143-93.143 90.857 112 227.429 185.143 380.571 193.143-2.857-13.714-4.571-28-4.571-42.286 0-101.714 82.286-184.571 184.571-184.571 53.143 0 101.143 22.286 134.857 58.286 41.714-8 81.714-23.429 117.143-44.571-13.714 42.857-42.857 78.857-81.143 101.714 37.143-4 73.143-14.286 106.286-28.571z"
              ></path>
            </svg>
            <a
              href="https://www.instagram.com/roytechinnovations?igsh=MWtna3AzN2gwbGR3cg=="
              target="_blank"
              rel="noreferrer noopener"
              class="contact-link"
            >
              <svg
                viewBox="0 0 877.7142857142857 1024"
                class="contact-icon12 socialIcons"
              >
                <path
                  d="M585.143 512c0-80.571-65.714-146.286-146.286-146.286s-146.286 65.714-146.286 146.286 65.714 146.286 146.286 146.286 146.286-65.714 146.286-146.286zM664 512c0 124.571-100.571 225.143-225.143 225.143s-225.143-100.571-225.143-225.143 100.571-225.143 225.143-225.143 225.143 100.571 225.143 225.143zM725.714 277.714c0 29.143-23.429 52.571-52.571 52.571s-52.571-23.429-52.571-52.571 23.429-52.571 52.571-52.571 52.571 23.429 52.571 52.571zM438.857 152c-64 0-201.143-5.143-258.857 17.714-20 8-34.857 17.714-50.286 33.143s-25.143 30.286-33.143 50.286c-22.857 57.714-17.714 194.857-17.714 258.857s-5.143 201.143 17.714 258.857c8 20 17.714 34.857 33.143 50.286s30.286 25.143 50.286 33.143c57.714 22.857 194.857 17.714 258.857 17.714s201.143 5.143 258.857-17.714c20-8 34.857-17.714 50.286-33.143s25.143-30.286 33.143-50.286c22.857-57.714 17.714-194.857 17.714-258.857s5.143-201.143-17.714-258.857c-8-20-17.714-34.857-33.143-50.286s-30.286-25.143-50.286-33.143c-57.714-22.857-194.857-17.714-258.857-17.714zM877.714 512c0 60.571 0.571 120.571-2.857 181.143-3.429 70.286-19.429 132.571-70.857 184s-113.714 67.429-184 70.857c-60.571 3.429-120.571 2.857-181.143 2.857s-120.571 0.571-181.143-2.857c-70.286-3.429-132.571-19.429-184-70.857s-67.429-113.714-70.857-184c-3.429-60.571-2.857-120.571-2.857-181.143s-0.571-120.571 2.857-181.143c3.429-70.286 19.429-132.571 70.857-184s113.714-67.429 184-70.857c60.571-3.429 120.571-2.857 181.143-2.857s120.571-0.571 181.143 2.857c70.286 3.429 132.571 19.429 184 70.857s67.429 113.714 70.857 184c3.429 60.571 2.857 120.571 2.857 181.143z"
                ></path>
              </svg>
            </a>
            <svg
              viewBox="0 0 602.2582857142856 1024"
              class="contact-icon14 socialIcons"
            >
              <path
                d="M548 6.857v150.857h-89.714c-70.286 0-83.429 33.714-83.429 82.286v108h167.429l-22.286 169.143h-145.143v433.714h-174.857v-433.714h-145.714v-169.143h145.714v-124.571c0-144.571 88.571-223.429 217.714-223.429 61.714 0 114.857 4.571 130.286 6.857z"
              ></path>
            </svg>
          </div>
        </div>
      </footer>
    </div>
  </div>
</template>

<script>
import AppContact14 from '../components/contact14'
import AppContact7 from '../components/contact7'

export default {
  name: 'Contact',
  props: {},
  components: {
    AppContact14,
    AppContact7,
  },
  metaInfo: {
    title: 'contact - Spotless Hungry Crocodile',
    meta: [
      {
        property: 'og:title',
        content: 'contact - Spotless Hungry Crocodile',
      },
    ],
  },
}
</script>

<style scoped>
.contact-container {
  width: 100%;
  display: flex;
  overflow: auto;
  min-height: 100vh;
  align-items: center;
  flex-direction: column;
}
.contact-header {
  width: 100%;
  display: flex;
  z-index: 100;
  position: fixed;
  align-items: center;
  flex-direction: column;
  background-color: var(--dl-color-gray-white);
}
.contact-desktop-menu {
  flex: 1;
  display: flex;
  justify-content: space-between;
}
.contact-links {
  flex: 1;
  display: flex;
  align-items: center;
  flex-direction: row;
  justify-content: center;
}
.contact-nav12 {
  text-decoration: none;
}
.contact-nav22 {
  margin-left: var(--dl-space-space-unit);
  text-decoration: none;
}
.contact-nav32 {
  margin-left: var(--dl-space-space-unit);
  text-decoration: none;
}
.contact-nav42 {
  margin-left: var(--dl-space-space-unit);
  text-decoration: none;
}
.contact-nav52 {
  margin-left: var(--dl-space-space-unit);
  text-decoration: none;
}
.contact-buttons {
  border: 2px dashed rgba(120, 120, 120, 0.4);
  display: flex;
  align-items: center;
  flex-direction: row;
  justify-content: space-between;
}
.contact-burger-menu {
  display: none;
}
.contact-icon {
  width: var(--dl-size-size-xsmall);
  cursor: pointer;
  height: var(--dl-size-size-xsmall);
}
.contact-mobile-menu1 {
  top: 0px;
  left: 0px;
  width: 100%;
  height: 100vh;
  display: none;
  padding: 32px;
  z-index: 100;
  position: absolute;
  flex-direction: column;
  justify-content: space-between;
}
.contact-nav {
  display: flex;
  align-items: flex-start;
  flex-direction: column;
}
.contact-top {
  width: 100%;
  display: flex;
  align-items: center;
  margin-bottom: var(--dl-space-space-threeunits);
  justify-content: space-between;
}
.contact-close-menu {
  display: flex;
  align-items: center;
  justify-content: center;
}
.contact-icon02 {
  width: var(--dl-size-size-xsmall);
  cursor: pointer;
  height: var(--dl-size-size-xsmall);
}
.contact-links1 {
  flex: 0 0 auto;
  display: flex;
  align-self: flex-start;
  align-items: flex-start;
  flex-direction: column;
}
.contact-nav121 {
  margin-bottom: var(--dl-space-space-unit);
}
.contact-nav221 {
  margin-bottom: var(--dl-space-space-unit);
}
.contact-nav321 {
  margin-bottom: var(--dl-space-space-unit);
}
.contact-nav421 {
  margin-bottom: var(--dl-space-space-unit);
}
.contact-nav521 {
  margin-bottom: var(--dl-space-space-unit);
}
.contact-buttons1 {
  display: flex;
  margin-top: var(--dl-space-space-unit);
  align-items: center;
  flex-direction: row;
  justify-content: space-between;
}
.contact-icon04 {
  width: var(--dl-size-size-xsmall);
  height: var(--dl-size-size-xsmall);
  margin-right: var(--dl-space-space-twounits);
}
.contact-icon06 {
  width: var(--dl-size-size-xsmall);
  height: var(--dl-size-size-xsmall);
  margin-right: var(--dl-space-space-twounits);
}
.contact-icon08 {
  width: var(--dl-size-size-xsmall);
  height: var(--dl-size-size-xsmall);
}
.contact-contactform2 {
  flex: 0 0 auto;
  width: 100%;
  height: auto;
  display: flex;
  align-items: center;
  justify-content: center;
}
.contact-contact9 {
  display: flex;
  position: relative;
  align-items: center;
  flex-direction: column;
}
.contact-image1 {
  flex: 1;
  width: auto;
  height: auto;
  max-width: 640px;
  border-radius: var(--dl-radius-radius-radius4);
}
.contact-content {
  gap: 0;
  flex: 1;
  align-items: stretch;
}
.contact-section-title {
  gap: var(--dl-space-space-unit);
  display: flex;
  align-self: stretch;
  align-items: flex-start;
  flex-direction: column;
}
.contact-content1 {
  gap: var(--dl-space-space-oneandhalfunits);
  display: flex;
  align-self: stretch;
  align-items: flex-start;
  flex-direction: column;
}
.contact-input {
  gap: var(--dl-space-space-halfunit);
  display: flex;
  align-self: stretch;
  flex-direction: column;
}
.contact-input1 {
  gap: var(--dl-space-space-halfunit);
  display: flex;
  align-self: stretch;
  flex-direction: column;
}
.contact-container1 {
  gap: var(--dl-space-space-halfunit);
  display: flex;
  align-items: flex-start;
  flex-direction: column;
  justify-content: center;
}
.contact-checkbox {
  gap: var(--dl-space-space-unit);
  display: flex;
  align-items: center;
}
.contact-text6 {
  height: auto;
  font-size: 14px;
  font-style: Regular;
  text-align: left;
  font-family: Roboto;
  font-weight: 400;
  line-height: 150%;
  font-stretch: normal;
  text-decoration: none;
}
.contact-button {
  align-self: flex-start;
  text-decoration: none;
}
.contact-contact3 {
  flex: 0 0 auto;
  width: 100%;
  height: auto;
  display: flex;
  align-items: center;
  justify-content: center;
}
.contact-contact4 {
  flex: 0 0 auto;
  width: 100%;
  height: auto;
  display: flex;
  align-items: center;
  justify-content: center;
}
.contact-footer {
  flex: 0 0 auto;
  width: 100%;
  height: auto;
  display: flex;
  align-items: center;
  justify-content: center;
}
.contact-container2 {
  gap: var(--dl-space-space-unit);
  display: flex;
  max-width: var(--dl-size-size-maxwidth);
  align-items: center;
  flex-direction: column;
  justify-content: flex-start;
}
.contact-nav1 {
  flex: 0 0 auto;
  display: flex;
  margin-top: 0px;
  align-items: center;
  flex-direction: row;
}
.contact-nav122 {
  text-decoration: none;
}
.contact-nav222 {
  margin-left: var(--dl-space-space-unit);
  text-decoration: none;
}
.contact-nav322 {
  margin-left: var(--dl-space-space-unit);
  text-decoration: none;
}
.contact-nav422 {
  margin-left: var(--dl-space-space-unit);
  text-decoration: none;
}
.contact-nav522 {
  margin-left: var(--dl-space-space-unit);
  text-decoration: none;
}
.contact-separator {
  flex: 0 0 auto;
  width: 100%;
  height: 0px;
  display: flex;
  margin-top: var(--dl-space-space-twounits);
  align-items: flex-start;
  margin-left: 0px;
  border-color: var(--dl-color-gray-900);
  border-style: solid;
  border-width: 1px;
  margin-right: 0px;
  margin-bottom: var(--dl-space-space-twounits);
  flex-direction: row;
  border-top-width: 0px;
  border-left-width: 0px;
  border-right-width: 0px;
}
.contact-container3 {
  flex: 0 0 auto;
  width: 100%;
  display: flex;
  align-items: center;
  flex-direction: row;
  justify-content: space-between;
}
.contact-icon-group1 {
  display: flex;
  align-items: center;
  flex-direction: row;
  justify-content: space-between;
}
.contact-icon10 {
  width: 24px;
  height: 24px;
  margin-right: var(--dl-space-space-twounits);
}
.contact-link {
  display: contents;
}
.contact-icon12 {
  width: 24px;
  height: 24px;
  margin-right: var(--dl-space-space-twounits);
  text-decoration: none;
}
.contact-icon14 {
  width: 24px;
  height: 24px;
}
@media(max-width: 991px) {
  .contact-max-width {
    flex-direction: column;
  }
  .contact-content {
    width: 100%;
  }
}
@media(max-width: 767px) {
  .contact-navbar-interactive {
    padding-left: var(--dl-space-space-twounits);
    padding-right: var(--dl-space-space-twounits);
  }
  .contact-desktop-menu {
    display: none;
  }
  .contact-burger-menu {
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .contact-nav121 {
    margin-bottom: var(--dl-space-space-unit);
  }
  .contact-nav221 {
    margin-bottom: var(--dl-space-space-unit);
  }
  .contact-nav321 {
    margin-bottom: var(--dl-space-space-unit);
  }
  .contact-nav421 {
    margin-bottom: var(--dl-space-space-unit);
  }
  .contact-nav521 {
    margin-bottom: var(--dl-space-space-unit);
  }
  .contact-image1 {
    width: 100%;
  }
  .contact-footer1 {
    padding-left: var(--dl-space-space-twounits);
    padding-right: var(--dl-space-space-twounits);
  }
  .contact-separator {
    margin-top: var(--dl-space-space-oneandhalfunits);
    margin-left: 0px;
    margin-right: 0px;
    margin-bottom: var(--dl-space-space-oneandhalfunits);
  }
  .contact-container3 {
    align-items: center;
    flex-direction: column;
    justify-content: space-between;
  }
}
@media(max-width: 479px) {
  .contact-navbar-interactive {
    padding: var(--dl-space-space-unit);
  }
  .contact-mobile-menu1 {
    padding: 16px;
  }
  .contact-footer1 {
    padding: var(--dl-space-space-unit);
  }
  .contact-separator {
    margin-top: var(--dl-space-space-oneandhalfunits);
    margin-bottom: var(--dl-space-space-oneandhalfunits);
  }
  .contact-container3 {
    align-items: center;
    flex-direction: column;
    justify-content: space-between;
  }
}
</style>
