<template>
  <div class="about-us-container">
    <div class="about-us-header">
      <header
        data-thq="thq-navbar"
        class="navbarContainer about-us-navbar-interactive"
      >
        <span class="logo">ROYTECHINNOVATIONS</span>
        <div data-thq="thq-navbar-nav" class="about-us-desktop-menu">
          <nav class="about-us-links">
            <router-link to="/" class="about-us-nav12 bodySmall">
              Home
            </router-link>
            <router-link to="/about-us" class="about-us-nav22 bodySmall">
              About Us
            </router-link>
            <router-link to="/services" class="about-us-nav32 bodySmall">
              Services
            </router-link>
            <a
              href="https://667ce7c72fc74.site123.me"
              target="_blank"
              rel="noreferrer noopener"
              class="about-us-nav42"
            >
              Minecraft
            </a>
            <router-link to="/contact" class="about-us-nav52 bodySmall">
              Contact
            </router-link>
          </nav>
          <div class="about-us-buttons"></div>
        </div>
        <div data-thq="thq-burger-menu" class="about-us-burger-menu">
          <svg viewBox="0 0 1024 1024" class="about-us-icon socialIcons">
            <path
              d="M128 554.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 298.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 810.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"
            ></path>
          </svg>
        </div>
        <div data-thq="thq-mobile-menu" class="about-us-mobile-menu1 mobileMenu">
          <div class="about-us-nav">
            <div class="about-us-top">
              <span class="logo">ROYTECHINNOVATIONS</span>
              <div data-thq="thq-close-menu" class="about-us-close-menu">
                <svg viewBox="0 0 1024 1024" class="about-us-icon02 socialIcons">
                  <path
                    d="M810 274l-238 238 238 238-60 60-238-238-238 238-60-60 238-238-238-238 60-60 238 238 238-238z"
                  ></path>
                </svg>
              </div>
            </div>
            <nav class="about-us-links1">
              <span class="about-us-nav121 bodySmall">Home</span>
              <span class="about-us-nav221 bodySmall">About Us</span>
              <span class="about-us-nav321 bodySmall">Services</span>
              <span class="about-us-nav421 bodySmall">Products</span>
              <span class="about-us-nav521 bodySmall">Contact</span>
            </nav>
            <div class="about-us-buttons1">
              <button class="buttonFlat">Login</button>
              <button class="buttonFilled">Register</button>
            </div>
          </div>
          <div>
            <svg
              viewBox="0 0 950.8571428571428 1024"
              class="about-us-icon04 socialIcons"
            >
              <path
                d="M925.714 233.143c-25.143 36.571-56.571 69.143-92.571 95.429 0.571 8 0.571 16 0.571 24 0 244-185.714 525.143-525.143 525.143-104.571 0-201.714-30.286-283.429-82.857 14.857 1.714 29.143 2.286 44.571 2.286 86.286 0 165.714-29.143 229.143-78.857-81.143-1.714-149.143-54.857-172.571-128 11.429 1.714 22.857 2.857 34.857 2.857 16.571 0 33.143-2.286 48.571-6.286-84.571-17.143-148-91.429-148-181.143v-2.286c24.571 13.714 53.143 22.286 83.429 23.429-49.714-33.143-82.286-89.714-82.286-153.714 0-34.286 9.143-65.714 25.143-93.143 90.857 112 227.429 185.143 380.571 193.143-2.857-13.714-4.571-28-4.571-42.286 0-101.714 82.286-184.571 184.571-184.571 53.143 0 101.143 22.286 134.857 58.286 41.714-8 81.714-23.429 117.143-44.571-13.714 42.857-42.857 78.857-81.143 101.714 37.143-4 73.143-14.286 106.286-28.571z"
              ></path></svg
            ><svg
              viewBox="0 0 877.7142857142857 1024"
              class="about-us-icon06 socialIcons"
            >
              <path
                d="M585.143 512c0-80.571-65.714-146.286-146.286-146.286s-146.286 65.714-146.286 146.286 65.714 146.286 146.286 146.286 146.286-65.714 146.286-146.286zM664 512c0 124.571-100.571 225.143-225.143 225.143s-225.143-100.571-225.143-225.143 100.571-225.143 225.143-225.143 225.143 100.571 225.143 225.143zM725.714 277.714c0 29.143-23.429 52.571-52.571 52.571s-52.571-23.429-52.571-52.571 23.429-52.571 52.571-52.571 52.571 23.429 52.571 52.571zM438.857 152c-64 0-201.143-5.143-258.857 17.714-20 8-34.857 17.714-50.286 33.143s-25.143 30.286-33.143 50.286c-22.857 57.714-17.714 194.857-17.714 258.857s-5.143 201.143 17.714 258.857c8 20 17.714 34.857 33.143 50.286s30.286 25.143 50.286 33.143c57.714 22.857 194.857 17.714 258.857 17.714s201.143 5.143 258.857-17.714c20-8 34.857-17.714 50.286-33.143s25.143-30.286 33.143-50.286c22.857-57.714 17.714-194.857 17.714-258.857s5.143-201.143-17.714-258.857c-8-20-17.714-34.857-33.143-50.286s-30.286-25.143-50.286-33.143c-57.714-22.857-194.857-17.714-258.857-17.714zM877.714 512c0 60.571 0.571 120.571-2.857 181.143-3.429 70.286-19.429 132.571-70.857 184s-113.714 67.429-184 70.857c-60.571 3.429-120.571 2.857-181.143 2.857s-120.571 0.571-181.143-2.857c-70.286-3.429-132.571-19.429-184-70.857s-67.429-113.714-70.857-184c-3.429-60.571-2.857-120.571-2.857-181.143s-0.571-120.571 2.857-181.143c3.429-70.286 19.429-132.571 70.857-184s113.714-67.429 184-70.857c60.571-3.429 120.571-2.857 181.143-2.857s120.571-0.571 181.143 2.857c70.286 3.429 132.571 19.429 184 70.857s67.429 113.714 70.857 184c3.429 60.571 2.857 120.571 2.857 181.143z"
              ></path></svg
            ><svg
              viewBox="0 0 602.2582857142856 1024"
              class="about-us-icon08 socialIcons"
            >
              <path
                d="M548 6.857v150.857h-89.714c-70.286 0-83.429 33.714-83.429 82.286v108h167.429l-22.286 169.143h-145.143v433.714h-174.857v-433.714h-145.714v-169.143h145.714v-124.571c0-144.571 88.571-223.429 217.714-223.429 61.714 0 114.857 4.571 130.286 6.857z"
              ></path>
            </svg>
          </div>
        </div>
      </header>
    </div>
    <div class="about-us-hero2">
      <div class="about-us-header26 thq-section-padding">
        <div class="about-us-max-width thq-flex-column thq-section-max-width">
          <div class="about-us-column">
            <div class="about-us-content">
              <h1 class="about-us-text thq-heading-1">
                Welcome to RoyTechInnovations
              </h1>
              <p class="about-us-text1 thq-body-large">
                Revolutionize your business with cutting-edge technological
                solutions
              </p>
              <div class="about-us-actions">
                <button class="thq-button-filled about-us-button">
                  <span class="thq-body-small">Learn More</span>
                </button>
                <router-link to="/contact" class="about-us-navlink">
                  <app-button class="about-us-component"></app-button>
                </router-link>
              </div>
            </div>
          </div>
          <img
            alt="RoyTechInnovations Logo"
            src="https://images.unsplash.com/photo-1507925921958-8a62f3d1a50d?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTcwMDU5MHw&amp;ixlib=rb-4.0.3&amp;q=80&amp;w=1080"
            class="thq-img-ratio-16-9"
          />
        </div>
      </div>
    </div>
    <div class="about-us-stats3">
      <app-stats2
        image1Src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRPCrTmz_8M5W5zqcaUZdl1QALPOTpGN0jFrQ&amp;s"
      ></app-stats2>
    </div>
    <div class="about-us-logos4"><app-logos1></app-logos1></div>
    <div class="about-us-features5">
      <app-features1
        feature1ImageSrc="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSBRWQEnUR6gUVI_oSo4sJTvRUzRIyAoLROcw&amp;s"
      ></app-features1>
    </div>
    <div class="about-us-team6"></div>
    <div class="about-us-footer">
      <footer class="footerContainer about-us-footer1">
        <div class="about-us-container1">
          <span class="logo">ROYTECHINNOVATIONS</span>
          <nav class="about-us-nav1">
            <router-link to="/" class="about-us-nav122 bodySmall">
              Home
            </router-link>
            <router-link to="/about-us" class="about-us-nav222 bodySmall">
              About Us
            </router-link>
            <router-link to="/services" class="about-us-nav322 bodySmall">
              Services
            </router-link>
            <a
              href="https://667ce7c72fc74.site123.me"
              target="_blank"
              rel="noreferrer noopener"
              class="about-us-nav422"
            >
              Minecraft
            </a>
            <router-link to="/contact" class="about-us-nav522 bodySmall">
              Contact
            </router-link>
          </nav>
        </div>
        <div class="about-us-separator"></div>
        <div class="about-us-container2">
          <div class="about-us-icon-group1">
            <svg
              viewBox="0 0 950.8571428571428 1024"
              class="about-us-icon10 socialIcons"
            >
              <path
                d="M925.714 233.143c-25.143 36.571-56.571 69.143-92.571 95.429 0.571 8 0.571 16 0.571 24 0 244-185.714 525.143-525.143 525.143-104.571 0-201.714-30.286-283.429-82.857 14.857 1.714 29.143 2.286 44.571 2.286 86.286 0 165.714-29.143 229.143-78.857-81.143-1.714-149.143-54.857-172.571-128 11.429 1.714 22.857 2.857 34.857 2.857 16.571 0 33.143-2.286 48.571-6.286-84.571-17.143-148-91.429-148-181.143v-2.286c24.571 13.714 53.143 22.286 83.429 23.429-49.714-33.143-82.286-89.714-82.286-153.714 0-34.286 9.143-65.714 25.143-93.143 90.857 112 227.429 185.143 380.571 193.143-2.857-13.714-4.571-28-4.571-42.286 0-101.714 82.286-184.571 184.571-184.571 53.143 0 101.143 22.286 134.857 58.286 41.714-8 81.714-23.429 117.143-44.571-13.714 42.857-42.857 78.857-81.143 101.714 37.143-4 73.143-14.286 106.286-28.571z"
              ></path>
            </svg>
            <a
              href="https://www.instagram.com/roytechinnovations?igsh=MWtna3AzN2gwbGR3cg=="
              target="_blank"
              rel="noreferrer noopener"
              class="about-us-link"
            >
              <svg
                viewBox="0 0 877.7142857142857 1024"
                class="about-us-icon12 socialIcons"
              >
                <path
                  d="M585.143 512c0-80.571-65.714-146.286-146.286-146.286s-146.286 65.714-146.286 146.286 65.714 146.286 146.286 146.286 146.286-65.714 146.286-146.286zM664 512c0 124.571-100.571 225.143-225.143 225.143s-225.143-100.571-225.143-225.143 100.571-225.143 225.143-225.143 225.143 100.571 225.143 225.143zM725.714 277.714c0 29.143-23.429 52.571-52.571 52.571s-52.571-23.429-52.571-52.571 23.429-52.571 52.571-52.571 52.571 23.429 52.571 52.571zM438.857 152c-64 0-201.143-5.143-258.857 17.714-20 8-34.857 17.714-50.286 33.143s-25.143 30.286-33.143 50.286c-22.857 57.714-17.714 194.857-17.714 258.857s-5.143 201.143 17.714 258.857c8 20 17.714 34.857 33.143 50.286s30.286 25.143 50.286 33.143c57.714 22.857 194.857 17.714 258.857 17.714s201.143 5.143 258.857-17.714c20-8 34.857-17.714 50.286-33.143s25.143-30.286 33.143-50.286c22.857-57.714 17.714-194.857 17.714-258.857s5.143-201.143-17.714-258.857c-8-20-17.714-34.857-33.143-50.286s-30.286-25.143-50.286-33.143c-57.714-22.857-194.857-17.714-258.857-17.714zM877.714 512c0 60.571 0.571 120.571-2.857 181.143-3.429 70.286-19.429 132.571-70.857 184s-113.714 67.429-184 70.857c-60.571 3.429-120.571 2.857-181.143 2.857s-120.571 0.571-181.143-2.857c-70.286-3.429-132.571-19.429-184-70.857s-67.429-113.714-70.857-184c-3.429-60.571-2.857-120.571-2.857-181.143s-0.571-120.571 2.857-181.143c3.429-70.286 19.429-132.571 70.857-184s113.714-67.429 184-70.857c60.571-3.429 120.571-2.857 181.143-2.857s120.571-0.571 181.143 2.857c70.286 3.429 132.571 19.429 184 70.857s67.429 113.714 70.857 184c3.429 60.571 2.857 120.571 2.857 181.143z"
                ></path>
              </svg>
            </a>
            <svg
              viewBox="0 0 602.2582857142856 1024"
              class="about-us-icon14 socialIcons"
            >
              <path
                d="M548 6.857v150.857h-89.714c-70.286 0-83.429 33.714-83.429 82.286v108h167.429l-22.286 169.143h-145.143v433.714h-174.857v-433.714h-145.714v-169.143h145.714v-124.571c0-144.571 88.571-223.429 217.714-223.429 61.714 0 114.857 4.571 130.286 6.857z"
              ></path>
            </svg>
          </div>
        </div>
      </footer>
    </div>
  </div>
</template>

<script>
import AppButton from '../components/button'
import AppStats2 from '../components/stats2'
import AppLogos1 from '../components/logos1'
import AppFeatures1 from '../components/features1'

export default {
  name: 'AboutUs',
  props: {},
  components: {
    AppButton,
    AppStats2,
    AppLogos1,
    AppFeatures1,
  },
  metaInfo: {
    title: 'About-Us - Spotless Hungry Crocodile',
    meta: [
      {
        property: 'og:title',
        content: 'About-Us - Spotless Hungry Crocodile',
      },
    ],
  },
}
</script>

<style scoped>
.about-us-container {
  width: 100%;
  display: flex;
  overflow: auto;
  min-height: 100vh;
  align-items: center;
  flex-direction: column;
}
.about-us-header {
  width: 100%;
  display: flex;
  z-index: 100;
  position: fixed;
  align-items: center;
  flex-direction: column;
  background-color: var(--dl-color-gray-white);
}
.about-us-desktop-menu {
  flex: 1;
  display: flex;
  justify-content: space-between;
}
.about-us-links {
  flex: 1;
  display: flex;
  align-items: center;
  flex-direction: row;
  justify-content: center;
}
.about-us-nav12 {
  text-decoration: none;
}
.about-us-nav22 {
  margin-left: var(--dl-space-space-unit);
  text-decoration: none;
}
.about-us-nav32 {
  margin-left: var(--dl-space-space-unit);
  text-decoration: none;
}
.about-us-nav42 {
  margin-left: var(--dl-space-space-unit);
  text-decoration: none;
}
.about-us-nav52 {
  margin-left: var(--dl-space-space-unit);
  text-decoration: none;
}
.about-us-buttons {
  border: 2px dashed rgba(120, 120, 120, 0.4);
  display: flex;
  align-items: center;
  flex-direction: row;
  justify-content: space-between;
}
.about-us-burger-menu {
  display: none;
}
.about-us-icon {
  width: var(--dl-size-size-xsmall);
  cursor: pointer;
  height: var(--dl-size-size-xsmall);
}
.about-us-mobile-menu1 {
  top: 0px;
  left: 0px;
  width: 100%;
  height: 100vh;
  display: none;
  padding: 32px;
  z-index: 100;
  position: absolute;
  flex-direction: column;
  justify-content: space-between;
}
.about-us-nav {
  display: flex;
  align-items: flex-start;
  flex-direction: column;
}
.about-us-top {
  width: 100%;
  display: flex;
  align-items: center;
  margin-bottom: var(--dl-space-space-threeunits);
  justify-content: space-between;
}
.about-us-close-menu {
  display: flex;
  align-items: center;
  justify-content: center;
}
.about-us-icon02 {
  width: var(--dl-size-size-xsmall);
  cursor: pointer;
  height: var(--dl-size-size-xsmall);
}
.about-us-links1 {
  flex: 0 0 auto;
  display: flex;
  align-self: flex-start;
  align-items: flex-start;
  flex-direction: column;
}
.about-us-nav121 {
  margin-bottom: var(--dl-space-space-unit);
}
.about-us-nav221 {
  margin-bottom: var(--dl-space-space-unit);
}
.about-us-nav321 {
  margin-bottom: var(--dl-space-space-unit);
}
.about-us-nav421 {
  margin-bottom: var(--dl-space-space-unit);
}
.about-us-nav521 {
  margin-bottom: var(--dl-space-space-unit);
}
.about-us-buttons1 {
  display: flex;
  margin-top: var(--dl-space-space-unit);
  align-items: center;
  flex-direction: row;
  justify-content: space-between;
}
.about-us-icon04 {
  width: var(--dl-size-size-xsmall);
  height: var(--dl-size-size-xsmall);
  margin-right: var(--dl-space-space-twounits);
}
.about-us-icon06 {
  width: var(--dl-size-size-xsmall);
  height: var(--dl-size-size-xsmall);
  margin-right: var(--dl-space-space-twounits);
}
.about-us-icon08 {
  width: var(--dl-size-size-xsmall);
  height: var(--dl-size-size-xsmall);
}
.about-us-hero2 {
  flex: 0 0 auto;
  width: 100%;
  height: auto;
  display: flex;
  align-items: center;
  justify-content: center;
}
.about-us-header26 {
  gap: var(--dl-space-space-twounits);
}
.about-us-max-width {
  align-self: center;
}
.about-us-column {
  gap: var(--dl-space-space-oneandhalfunits);
  width: 100%;
  display: flex;
  align-items: center;
  flex-shrink: 0;
  flex-direction: column;
}
.about-us-content {
  gap: var(--dl-space-space-oneandhalfunits);
  width: 100%;
  display: flex;
  align-self: stretch;
  align-items: center;
  flex-direction: column;
}
.about-us-text {
  text-align: center;
}
.about-us-text1 {
  text-align: center;
}
.about-us-actions {
  gap: var(--dl-space-space-unit);
  display: flex;
  align-items: flex-start;
}
.about-us-navlink {
  display: contents;
}
.about-us-component {
  text-decoration: none;
}
.about-us-stats3 {
  flex: 0 0 auto;
  width: 100%;
  height: auto;
  display: flex;
  align-items: center;
  justify-content: center;
}
.about-us-logos4 {
  flex: 0 0 auto;
  width: 100%;
  height: auto;
  display: flex;
  align-items: center;
  justify-content: center;
}
.about-us-features5 {
  flex: 0 0 auto;
  width: 100%;
  height: auto;
  display: flex;
  align-items: center;
  justify-content: center;
}
.about-us-team6 {
  flex: 0 0 auto;
  width: 100%;
  height: auto;
  display: flex;
  align-items: center;
  justify-content: center;
}
.about-us-footer {
  flex: 0 0 auto;
  width: 100%;
  height: auto;
  display: flex;
  align-items: center;
  justify-content: center;
}
.about-us-container1 {
  gap: var(--dl-space-space-unit);
  display: flex;
  max-width: var(--dl-size-size-maxwidth);
  align-items: center;
  flex-direction: column;
  justify-content: flex-start;
}
.about-us-nav1 {
  flex: 0 0 auto;
  display: flex;
  margin-top: 0px;
  align-items: center;
  flex-direction: row;
}
.about-us-nav122 {
  text-decoration: none;
}
.about-us-nav222 {
  margin-left: var(--dl-space-space-unit);
  text-decoration: none;
}
.about-us-nav322 {
  margin-left: var(--dl-space-space-unit);
  text-decoration: none;
}
.about-us-nav422 {
  margin-left: var(--dl-space-space-unit);
  text-decoration: none;
}
.about-us-nav522 {
  margin-left: var(--dl-space-space-unit);
  text-decoration: none;
}
.about-us-separator {
  flex: 0 0 auto;
  width: 100%;
  height: 0px;
  display: flex;
  margin-top: var(--dl-space-space-twounits);
  align-items: flex-start;
  margin-left: 0px;
  border-color: var(--dl-color-gray-900);
  border-style: solid;
  border-width: 1px;
  margin-right: 0px;
  margin-bottom: var(--dl-space-space-twounits);
  flex-direction: row;
  border-top-width: 0px;
  border-left-width: 0px;
  border-right-width: 0px;
}
.about-us-container2 {
  flex: 0 0 auto;
  width: 100%;
  display: flex;
  align-items: center;
  flex-direction: row;
  justify-content: space-between;
}
.about-us-icon-group1 {
  display: flex;
  align-items: center;
  flex-direction: row;
  justify-content: space-between;
}
.about-us-icon10 {
  width: 24px;
  height: 24px;
  margin-right: var(--dl-space-space-twounits);
}
.about-us-link {
  display: contents;
}
.about-us-icon12 {
  width: 24px;
  height: 24px;
  margin-right: var(--dl-space-space-twounits);
  text-decoration: none;
}
.about-us-icon14 {
  width: 24px;
  height: 24px;
}
@media(max-width: 767px) {
  .about-us-navbar-interactive {
    padding-left: var(--dl-space-space-twounits);
    padding-right: var(--dl-space-space-twounits);
  }
  .about-us-desktop-menu {
    display: none;
  }
  .about-us-burger-menu {
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .about-us-nav121 {
    margin-bottom: var(--dl-space-space-unit);
  }
  .about-us-nav221 {
    margin-bottom: var(--dl-space-space-unit);
  }
  .about-us-nav321 {
    margin-bottom: var(--dl-space-space-unit);
  }
  .about-us-nav421 {
    margin-bottom: var(--dl-space-space-unit);
  }
  .about-us-nav521 {
    margin-bottom: var(--dl-space-space-unit);
  }
  .about-us-footer1 {
    padding-left: var(--dl-space-space-twounits);
    padding-right: var(--dl-space-space-twounits);
  }
  .about-us-separator {
    margin-top: var(--dl-space-space-oneandhalfunits);
    margin-left: 0px;
    margin-right: 0px;
    margin-bottom: var(--dl-space-space-oneandhalfunits);
  }
  .about-us-container2 {
    align-items: center;
    flex-direction: column;
    justify-content: space-between;
  }
}
@media(max-width: 479px) {
  .about-us-navbar-interactive {
    padding: var(--dl-space-space-unit);
  }
  .about-us-mobile-menu1 {
    padding: 16px;
  }
  .about-us-actions {
    width: 100%;
    flex-direction: column;
  }
  .about-us-button {
    width: 100%;
  }
  .about-us-footer1 {
    padding: var(--dl-space-space-unit);
  }
  .about-us-separator {
    margin-top: var(--dl-space-space-oneandhalfunits);
    margin-bottom: var(--dl-space-space-oneandhalfunits);
  }
  .about-us-container2 {
    align-items: center;
    flex-direction: column;
    justify-content: space-between;
  }
}
</style>
