<template>
  <div class="thq-section-padding">
    <div class="stats1-max-width thq-section-max-width">
      <div class="stats1-container1 thq-flex-column">
        <span class="thq-body-small">{{ content1 }}</span>
        <h2 class="thq-heading-2">{{ heading1 }}</h2>
        <p class="thq-body-large">{{ content2 }}</p>
        <div class="stats1-container2">
          <div class="stats1-container3">
            <h2 class="thq-heading-2">{{ stat1 }}</h2>
            <span class="thq-body-small">{{ stat1Description }}</span>
          </div>
          <div class="stats1-container4">
            <h2 class="thq-heading-2">{{ stat2 }}</h2>
            <span class="thq-body-small">{{ stat2Description }}</span>
          </div>
        </div>
        <div class="stats1-container5">
          <div class="stats1-container6">
            <h2 class="thq-heading-2">{{ stat3 }}</h2>
            <span class="thq-body-small">{{ stat3Description }}</span>
          </div>
          <div class="stats1-container7">
            <h2 class="thq-heading-2">{{ stat4 }}</h2>
            <span class="thq-body-small">{{ stat4Description }}</span>
          </div>
        </div>
      </div>
      <div class="stats1-container8">
        <img
          :alt="image1Alt"
          :src="image1Src"
          class="thq-img-ratio-1-1 stats1-image"
        />
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Stats1',
  props: {
    heading1: {
      type: String,
      default: 'Customer results presented in a fashion way',
    },
    content2: {
      type: String,
      default:
        'Business improvements emphasized with numbers to increase creadibility',
    },
    image1Alt: {
      type: String,
      default: 'image',
    },
    content1: {
      type: String,
      default: 'Customer Feedback',
    },
    stat1: {
      type: String,
      default: 'Customized Solutions',
    },
    stat4: {
      type: String,
      default: 'Cutting-Edge Technology',
    },
    stat3: {
      type: String,
      default: 'Competitive Advantage',
    },
    image1Src: {
      type: String,
      default:
        'https://images.unsplash.com/photo-1593376853899-fbb47a057fa0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyM3w&ixlib=rb-4.0.3&q=80&w=1080',
    },
    stat2Description: {
      type: String,
      default: 'Focus on quality and efficiency to drive innovation',
    },
    stat1Description: {
      type: String,
      default: 'Tailored services to meet the unique needs of each business',
    },
    stat2: {
      type: String,
      default: 'Customer Satisfaction',
    },
    stat4Description: {
      type: String,
      default: 'Revolutionizing businesses with innovative solutions',
    },
    stat3Description: {
      type: String,
      default: 'Helping businesses stay ahead in the market',
    },
  },
}
</script>

<style scoped>
.stats1-max-width {
  gap: var(--dl-space-space-twounits);
  flex: 0 0 auto;
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: flex-start;
}
.stats1-container1 {
  align-self: center;
  align-items: flex-start;
}
.stats1-container2 {
  flex: 0 0 auto;
  width: 100%;
  display: flex;
  align-items: flex-start;
  flex-direction: row;
}
.stats1-container3 {
  flex: 0 0 auto;
  width: 50%;
  display: flex;
  align-items: flex-start;
  flex-direction: column;
}
.stats1-container4 {
  flex: 0 0 auto;
  width: 50%;
  display: flex;
  align-items: flex-start;
  flex-direction: column;
}
.stats1-container5 {
  flex: 0 0 auto;
  width: 100%;
  display: flex;
  align-items: flex-start;
  flex-direction: row;
}
.stats1-container6 {
  flex: 0 0 auto;
  width: 50%;
  display: flex;
  align-items: flex-start;
  flex-direction: column;
}
.stats1-container7 {
  flex: 0 0 auto;
  width: 50%;
  display: flex;
  align-items: flex-start;
  flex-direction: column;
}
@media(max-width: 991px) {
  .stats1-max-width {
    gap: var(--dl-space-space-twounits);
    flex-direction: column;
  }
  .stats1-container8 {
    width: 100%;
  }
}
@media(max-width: 479px) {
  .stats1-image {
    width: 100%;
  }
}
</style>
