<template>
  <div class="app-component-container"></div>
</template>

<script>
export default {
  name: 'AppComponent',
  props: {},
}
</script>

<style scoped>
.app-component-container {
  width: 100%;
  height: 400px;
  display: flex;
  position: relative;
  align-items: flex-start;
  flex-direction: column;
}
</style>
