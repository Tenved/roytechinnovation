<template>
  <div class="contact7-container thq-section-padding">
    <div class="contact7-max-width thq-section-max-width">
      <div class="contact7-content thq-flex-row">
        <div class="contact7-content1">
          <h2 class="thq-heading-2">{{ heading1 }}</h2>
          <p class="thq-body-large">{{ content1 }}</p>
        </div>
      </div>
      <div class="contact7-content2 thq-flex-row">
        <div class="contact7-container1">
          <img
            :alt="location1ImgAlt"
            :src="location1ImgSrc"
            class="contact7-image thq-img-ratio-16-9"
          />
          <h3 class="contact7-text2 thq-heading-3">{{ location1 }}</h3>
          <p class="thq-body-large">{{ location1Description }}</p>
          <div class="contact7-container2">
            <span class="thq-button-flat thq-body-small">Get directions</span>
          </div>
        </div>
        <div class="contact7-container3">
          <img
            :alt="location2ImgAlt"
            :src="location2ImgSrc"
            class="contact7-image1 thq-img-ratio-16-9"
          />
          <h3 class="contact7-text5 thq-heading-3">{{ location2 }}</h3>
          <p class="thq-body-large">{{ location2Description }}</p>
          <div class="contact7-container4">
            <span class="thq-button-flat thq-body-small">Get directions</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Contact7',
  props: {
    location1ImgSrc: {
      type: String,
      default:
        'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTcwMjUzM3w&ixlib=rb-4.0.3&q=80&w=1080',
    },
    location2ImgSrc: {
      type: String,
      default:
        'https://images.unsplash.com/photo-1554325139-bbd006cd3e5a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTcwMjUzM3w&ixlib=rb-4.0.3&q=80&w=1080',
    },
    location2Description: {
      type: String,
      default: '456 Innovation Avenue, Tech Town, USA',
    },
    location1: {
      type: String,
      default: 'Headquarters',
    },
    location2: {
      type: String,
      default: 'Support Center',
    },
    location1ImgAlt: {
      type: String,
      default: 'Headquarters Image',
    },
    heading1: {
      type: String,
      default: 'Contact Us',
    },
    location2ImgAlt: {
      type: String,
      default: 'Support Center Image',
    },
    content1: {
      type: String,
      default:
        'For inquiries or to schedule a consultation, please contact us at headquarters@roytechinnovations.com',
    },
    location1Description: {
      type: String,
      default: '123 Innovation Street, Tech City, USA',
    },
  },
}
</script>

<style scoped>
.contact7-container {
  display: flex;
  position: relative;
  align-items: flex-start;
  flex-direction: column;
}
.contact7-max-width {
  align-self: center;
}
.contact7-content {
  width: 100%;
  margin-bottom: var(--dl-space-space-threeunits);
  justify-content: center;
}
.contact7-content1 {
  gap: var(--dl-space-space-unit);
  display: flex;
  align-self: stretch;
  align-items: center;
  flex-direction: column;
}
.contact7-content2 {
  width: 100%;
  align-items: flex-start;
  flex-direction: row;
  justify-content: space-between;
}
.contact7-container1 {
  gap: var(--dl-space-space-oneandhalfunits);
  flex: 1;
  display: flex;
  align-items: center;
  flex-direction: column;
}
.contact7-image {
  object-fit: cover;
}
.contact7-text2 {
  text-align: center;
}
.contact7-container2 {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: flex-start;
  justify-content: center;
}
.contact7-container3 {
  gap: var(--dl-space-space-oneandhalfunits);
  flex: 1;
  display: flex;
  align-items: center;
  flex-direction: column;
}
.contact7-image1 {
  object-fit: cover;
}
.contact7-text5 {
  text-align: center;
}
.contact7-container4 {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: flex-start;
  justify-content: center;
}
@media(max-width: 991px) {
  .contact7-content {
    align-items: flex-start;
    justify-content: flex-start;
  }
  .contact7-content2 {
    align-items: center;
    flex-direction: column;
  }
}
@media(max-width: 767px) {
  .contact7-content {
    gap: var(--dl-space-space-oneandhalfunits);
  }
  .contact7-image {
    width: 100%;
  }
  .contact7-image1 {
    width: 100%;
  }
}
</style>
