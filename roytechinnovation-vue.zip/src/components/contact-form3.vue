<template>
  <div class="contact-form3-contact9 thq-section-padding">
    <div class="thq-flex-row thq-section-max-width contact-form3-max-width">
      <img
        :alt="imageAlt"
        :src="imageSrc"
        class="contact-form3-image1 thq-img-ratio-4-3"
      />
      <div class="contact-form3-content thq-flex-column">
        <div class="contact-form3-section-title thq-card">
          <span class="thq-body-small">{{ content2 }}</span>
          <div class="contact-form3-content1">
            <h2 class="thq-heading-2">{{ heading1 }}</h2>
            <span class="thq-body-small">{{ content1 }}</span>
          </div>
        </div>
        <form class="thq-card">
          <div class="contact-form3-input">
            <label for="contact-form-3-name" class="thq-body-small">Name</label>
            <input
              type="text"
              id="contact-form-3-name"
              placeholder="Name"
              class="thq-input"
            />
          </div>
          <div class="contact-form3-input1">
            <label for="contact-form-3-email" class="thq-body-small">Email</label>
            <input
              type="email"
              id="contact-form-3-email"
              required="true"
              placeholder="Email"
              class="thq-input"
            />
          </div>
          <div class="contact-form3-container">
            <label for="contact-form-3-message" class="thq-body-small">
              Message
            </label>
            <textarea
              id="contact-form-3-message"
              rows="3"
              placeholder="Enter your message"
              class="thq-input"
            ></textarea>
          </div>
          <div class="contact-form3-checkbox">
            <input
              type="checkbox"
              id="contact-form-3-check"
              checked="true"
              required="true"
              class="thq-checkbox"
            />
            <label
              for="contact-form-3-check"
              class="contact-form3-text6 thq-body-small"
            >
              I accept the Terms
            </label>
          </div>
          <button type="submit" class="contact-form3-button thq-button-filled">
            <span class="thq-body-small">{{ action }}</span>
          </button>
        </form>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'ContactForm3',
  props: {
    imageAlt: {
      type: String,
      default: 'Image1',
    },
    content1: {
      type: String,
      default: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. ',
    },
    heading1: {
      type: String,
      default: 'Contact us',
    },
    action: {
      type: String,
      default: '/submit_contact_form',
    },
    content2: {
      type: String,
      default: 'Get in touch with us',
    },
    imageSrc: {
      type: String,
      default:
        'https://images.unsplash.com/photo-1453726007388-5df12357fcc6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTcwMjUzNHw&ixlib=rb-4.0.3&q=80&w=1080',
    },
  },
}
</script>

<style scoped>
.contact-form3-contact9 {
  display: flex;
  position: relative;
  align-items: center;
  flex-direction: column;
}
.contact-form3-image1 {
  flex: 1;
  width: auto;
  height: auto;
  max-width: 640px;
  border-radius: var(--dl-radius-radius-radius4);
}
.contact-form3-content {
  gap: 0;
  flex: 1;
  align-items: stretch;
}
.contact-form3-section-title {
  gap: var(--dl-space-space-unit);
  display: flex;
  align-self: stretch;
  align-items: flex-start;
  flex-direction: column;
}
.contact-form3-content1 {
  gap: var(--dl-space-space-oneandhalfunits);
  display: flex;
  align-self: stretch;
  align-items: flex-start;
  flex-direction: column;
}
.contact-form3-input {
  gap: var(--dl-space-space-halfunit);
  display: flex;
  align-self: stretch;
  flex-direction: column;
}
.contact-form3-input1 {
  gap: var(--dl-space-space-halfunit);
  display: flex;
  align-self: stretch;
  flex-direction: column;
}
.contact-form3-container {
  gap: var(--dl-space-space-halfunit);
  display: flex;
  align-items: flex-start;
  flex-direction: column;
  justify-content: center;
}
.contact-form3-checkbox {
  gap: var(--dl-space-space-unit);
  display: flex;
  align-items: center;
}
.contact-form3-text6 {
  height: auto;
  font-size: 14px;
  font-style: Regular;
  text-align: left;
  font-family: Roboto;
  font-weight: 400;
  line-height: 150%;
  font-stretch: normal;
  text-decoration: none;
}
.contact-form3-button {
  align-self: flex-start;
}
@media(max-width: 991px) {
  .contact-form3-max-width {
    flex-direction: column;
  }
  .contact-form3-content {
    width: 100%;
  }
}
@media(max-width: 767px) {
  .contact-form3-image1 {
    width: 100%;
  }
}
</style>
