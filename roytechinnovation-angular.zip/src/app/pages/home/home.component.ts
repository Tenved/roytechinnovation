import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-home',
  templateUrl: 'home.component.html',
  styleUrls: ['home.component.css'],
})
export class Home {
  rawlg80: string = ' '
  rawtcnl: string = ' '
  rawhyt6: string = ' '
  rawzwg7: string = ' '
  rawnoe9: string = ' '
  raw3r8d: string = ' '
  rawrn76: string = ' '
  rawbuyb: string = ' '
  rawchp5: string = ' '
  rawf0zi: string = ' '
  rawl60a: string = ' '
  rawlmww: string = ' '
  rawme9c: string = ' '
  rawtjo9: string = ' '
  raw3rxg: string = ' '
  raw2743: string = ' '
  raw8zae: string = ' '
  rawvai6: string = ' '
  rawsa98: string = ' '
  rawz9qb: string = ' '
  raw866t: string = ' '
  constructor(private title: Title) {
    this.title.setTitle('Spotless Hungry Crocodile')
  }
}
