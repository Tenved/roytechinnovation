import { Component } from '@angular/core'
import { Title, Meta } from '@angular/platform-browser'

@Component({
  selector: 'app-minecraft',
  templateUrl: 'minecraft.component.html',
  styleUrls: ['minecraft.component.css'],
})
export class Minecraft {
  constructor(private title: Title, private meta: Meta) {
    this.title.setTitle('Minecraft - Spotless Hungry Crocodile')
    this.meta.addTags([
      {
        property: 'og:title',
        content: 'Minecraft - Spotless Hungry Crocodile',
      },
    ])
  }
}
