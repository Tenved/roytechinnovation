import { Component, Input } from '@angular/core'

@Component({
  selector: 'app-features17',
  templateUrl: 'features17.component.html',
  styleUrls: ['features17.component.css'],
})
export class Features17 {
  @Input()
  feature1Slogan: string = 'Tailored to Your Needs'
  @Input()
  feature1Description: string =
    'We offer personalized solutions designed to meet the specific requirements of each client, ensuring maximum efficiency and effectiveness.'
  @Input()
  feature1ImageAlt: string = 'Customized Solutions Image'
  @Input()
  feature1Title: string = 'Customized Solutions'
  @Input()
  feature1ImageSrc: string =
    'https://images.unsplash.com/photo-1488229297570-58520851e868?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxOTQxMjgxNXw&ixlib=rb-4.0.3&q=80&w=1080'
  constructor() {}
}
