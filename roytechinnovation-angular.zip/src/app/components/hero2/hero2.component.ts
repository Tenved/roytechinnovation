import { Component, Input } from '@angular/core'

@Component({
  selector: 'app-hero2',
  templateUrl: 'hero2.component.html',
  styleUrls: ['hero2.component.css'],
})
export class Hero2 {
  @Input()
  heading1: string = 'Welcome to RoyTechInnovations'
  @Input()
  image1Alt: string = 'Technology Solutions Image'
  @Input()
  content1: string =
    'Empowering businesses with cutting-edge technology solutions'
  @Input()
  image1Src: string =
    'https://images.unsplash.com/photo-1627810551083-aeae84ab3dfc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyM3w&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  action1: string = 'Learn More'
  @Input()
  action2: string = 'Contact Us'
  constructor() {}
}
