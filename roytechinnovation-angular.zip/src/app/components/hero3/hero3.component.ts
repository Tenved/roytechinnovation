import { Component, Input } from '@angular/core'

@Component({
  selector: 'app-hero3',
  templateUrl: 'hero3.component.html',
  styleUrls: ['hero3.component.css'],
})
export class Hero3 {
  @Input()
  action2: string = 'Get in touch'
  @Input()
  heading1: string = 'Welcome to RoyTechInnovations'
  @Input()
  image1Alt: string = 'Team of experts working together'
  @Input()
  content1: string =
    'Revolutionize your business with our cutting-edge solutions'
  @Input()
  action1: string = 'Learn more'
  @Input()
  image1Src: string = 'https://play.teleporthq.io/static/svg/default-img.svg'
  constructor() {}
}
