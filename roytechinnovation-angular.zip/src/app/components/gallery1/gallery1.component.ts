import { Component, Input } from '@angular/core'

@Component({
  selector: 'app-gallery1',
  templateUrl: 'gallery1.component.html',
  styleUrls: ['gallery1.component.css'],
})
export class Gallery1 {
  @Input()
  image3Alt: string = 'Image of advanced software development'
  @Input()
  image2Alt: string = 'Image of innovative business solutions'
  @Input()
  content1: string =
    'Take a look at some of our latest projects and technological solutions.'
  @Input()
  image1Src: string =
    'https://images.unsplash.com/photo-1536675572774-1b66ac2e26e9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxOTQxMjgxNHw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  image2Src: string = 'https://play.teleporthq.io/static/svg/default-img.svg'
  @Input()
  image3Src: string =
    'https://images.unsplash.com/photo-1505424297051-c3ad50b055ae?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxOTQxMjgxNHw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  heading1: string = 'Explore Our Innovations'
  @Input()
  image1Alt: string = 'Image of cutting-edge technology'
  constructor() {}
}
