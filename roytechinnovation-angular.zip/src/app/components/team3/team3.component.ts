import { Component, Input } from '@angular/core'

@Component({
  selector: 'app-team3',
  templateUrl: 'team3.component.html',
  styleUrls: ['team3.component.css'],
})
export class Team3 {
  @Input()
  content1: string =
    'Our team is composed of highly skilled professionals dedicated to providing top-notch technology solutions for our clients.'
  @Input()
  member3: string = 'Michael Johnson'
  @Input()
  member1Job: string = 'CEO & Founder'
  @Input()
  member3Src: string =
    'https://images.unsplash.com/photo-1636041282523-1add6c493ebc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNXw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  member4Content: string =
    'Emily excels at building strong relationships with our clients, ensuring their needs are met and their expectations exceeded.'
  @Input()
  heading1: string = 'Meet Our Team'
  @Input()
  member3Job: string = 'Lead Developer'
  @Input()
  actionContent: string = 'Open positions'
  @Input()
  member3Alt: string = 'Image of Michael Johnson'
  @Input()
  member2Src: string =
    'https://images.unsplash.com/photo-1624224971170-2f84fed5eb5e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNnw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  member2: string = 'Jane Smith'
  @Input()
  member1: string = 'John Doe'
  @Input()
  member2Alt: string = 'Image of Jane Smith'
  @Input()
  member1Content: string =
    'John is a visionary leader with a passion for innovation and technology. With years of experience in the industry, he drives the company towards success.'
  @Input()
  member1Alt: string = 'Image of John Doe'
  @Input()
  content3: string = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. '
  @Input()
  member2Content: string =
    'Jane is a tech expert with a keen eye for detail. She oversees the technical aspects of our projects, ensuring they meet the highest standards.'
  @Input()
  member3Content: string =
    'Michael is a coding wizard who brings creativity and efficiency to our development processes. His expertise helps us deliver cutting-edge solutions.'
  @Input()
  member4Src: string =
    'https://images.unsplash.com/photo-1557040135-9dc2a6b60411?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNXw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  member4Alt: string = 'Image of Emily Brown'
  @Input()
  member4: string = 'Emily Brown'
  @Input()
  member4Job: string = 'Customer Relations Manager'
  @Input()
  heading2: string = 'We’re hiring!'
  @Input()
  member1Src: string =
    'https://images.unsplash.com/photo-1474447976065-67d23accb1e3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNXw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  member2Job: string = 'CTO'
  @Input()
  content2: string = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. '
  constructor() {}
}
