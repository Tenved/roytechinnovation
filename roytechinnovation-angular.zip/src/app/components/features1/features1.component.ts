import { Component, Input } from '@angular/core'

@Component({
  selector: 'app-features1',
  templateUrl: 'features1.component.html',
  styleUrls: ['features1.component.css'],
})
export class Features1 {
  @Input()
  feature2ImageSrc: string =
    'https://images.unsplash.com/photo-1627384113790-0e7a2679fda8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTcwMDU5MXw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  secondaryAction: string = 'Learn More'
  @Input()
  sectionDescription: string =
    'Explore the cutting-edge features that set RoyTechInnovations apart from the rest.'
  @Input()
  feature2Description: string =
    'Our services are designed to streamline processes and enhance productivity for your business.'
  @Input()
  feature1Title: string = 'Tailored Products'
  @Input()
  feature1Description: string =
    'We design and deliver products that are customized to fit the specific needs of your business.'
  @Input()
  sectionTitle: string = 'Our Features'
  @Input()
  feature3Description: string =
    'We prioritize customer satisfaction by providing top-notch support and solutions that exceed expectations.'
  @Input()
  slogan: string = 'Innovation. Quality. Efficiency.'
  @Input()
  feature3Title: string = 'Customer Satisfaction'
  @Input()
  feature1ImageSrc: string =
    'https://play.teleporthq.io/static/svg/default-img.svg'
  @Input()
  feature1ImageAlt: string = 'Tailored Products Image'
  @Input()
  feature2ImageAlt: string = 'Efficient Services Image'
  @Input()
  feature3ImageAlt: string = 'Customer Satisfaction Image'
  @Input()
  feature2Title: string = 'Efficient Services'
  @Input()
  mainAction: string = 'Customized Solutions'
  @Input()
  feature3ImageSrc: string =
    'https://images.unsplash.com/photo-1480694313141-fce5e697ee25?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTcwMDU5Mnw&ixlib=rb-4.0.3&q=80&w=1080'
  constructor() {}
}
