import { Component, Input } from '@angular/core'

@Component({
  selector: 'app-features171',
  templateUrl: 'features171.component.html',
  styleUrls: ['features171.component.css'],
})
export class Features171 {
  @Input()
  feature1ImageSrc: string =
    'https://images.unsplash.com/photo-1546488854-29722671e979?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxOTQxMjgxNXw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  feature1ImageAlt: string = 'Customized Technological Solutions Image'
  @Input()
  feature1Slogan: string = 'Tailored to meet your business needs'
  @Input()
  feature1Description: string =
    'We offer personalized technological solutions designed specifically for your business, ensuring that you get the most out of our services.'
  @Input()
  feature1Title: string = 'Customized Technological Solutions'
  constructor() {}
}
