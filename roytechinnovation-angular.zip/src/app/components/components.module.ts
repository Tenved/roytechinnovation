import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { Hero2 } from './hero2/hero2.component'
import { Features171 } from './features171/features171.component'
import { Features17 } from './features17/features17.component'
import { FAQ1 } from './faq1/faq1.component'
import { Contact4 } from './contact4/contact4.component'
import { Gallery1 } from './gallery1/gallery1.component'
import { Button } from './button/button.component'
import { Features23 } from './features23/features23.component'
import { Contact7 } from './contact7/contact7.component'
import { AppComponent } from './component/component.component'
import { Team3 } from './team3/team3.component'
import { Hero8 } from './hero8/hero8.component'
import { Contact14 } from './contact14/contact14.component'
import { Features18 } from './features18/features18.component'
import { Logos9 } from './logos9/logos9.component'
import { Question1 } from './question1/question1.component'
import { Stats2 } from './stats2/stats2.component'
import { Hero3 } from './hero3/hero3.component'
import { Features1 } from './features1/features1.component'
import { Testimonial16 } from './testimonial16/testimonial16.component'
import { FeatureCard } from './feature-card/feature-card.component'
import { Stats1 } from './stats1/stats1.component'
import { ContactForm3 } from './contact-form3/contact-form3.component'
import { Logos1 } from './logos1/logos1.component'
import { CTA1 } from './cta1/cta1.component'

@NgModule({
  declarations: [
    Hero2,
    Features171,
    Features17,
    FAQ1,
    Contact4,
    Gallery1,
    Button,
    Features23,
    Contact7,
    AppComponent,
    Team3,
    Hero8,
    Contact14,
    Features18,
    Logos9,
    Question1,
    Stats2,
    Hero3,
    Features1,
    Testimonial16,
    FeatureCard,
    Stats1,
    ContactForm3,
    Logos1,
    CTA1,
  ],
  imports: [CommonModule, RouterModule],
  exports: [
    Hero2,
    Features171,
    Features17,
    FAQ1,
    Contact4,
    Gallery1,
    Button,
    Features23,
    Contact7,
    AppComponent,
    Team3,
    Hero8,
    Contact14,
    Features18,
    Logos9,
    Question1,
    Stats2,
    Hero3,
    Features1,
    Testimonial16,
    FeatureCard,
    Stats1,
    ContactForm3,
    Logos1,
    CTA1,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class ComponentsModule {}
