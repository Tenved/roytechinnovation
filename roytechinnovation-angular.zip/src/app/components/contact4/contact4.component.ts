import { Component, Input } from '@angular/core'

@Component({
  selector: 'app-contact4',
  templateUrl: 'contact4.component.html',
  styleUrls: ['contact4.component.css'],
})
export class Contact4 {
  @Input()
  content3: string =
    'Stay connected with us on social media for the latest updates and innovations.'
  @Input()
  content5: string = "Let's collaborate and drive innovation together!"
  @Input()
  address1: string = '456 Test Ave, Bucharest'
  @Input()
  heading1: string = 'Contact us'
  @Input()
  email1: string = 'hello@teleporthq.io'
  @Input()
  phone1: string = '+1 (555) 000-0000'
  @Input()
  content4: string =
    'We value your feedback and are committed to ensuring your satisfaction with our services.'
  @Input()
  content2: string =
    'Our team is ready to assist you and provide tailored solutions to meet your specific needs.'
  @Input()
  content1: string =
    'Feel free to reach out to us for any inquiries or to discuss how we can help your business thrive.'
  constructor() {}
}
