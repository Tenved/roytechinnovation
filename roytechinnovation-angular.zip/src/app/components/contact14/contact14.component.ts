import { Component, Input } from '@angular/core'

@Component({
  selector: 'app-contact14',
  templateUrl: 'contact14.component.html',
  styleUrls: ['contact14.component.css'],
})
export class Contact14 {
  @Input()
  email1: string = 'info@roytechinnovations.com'
  @Input()
  content3: string =
    'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in ero.'
  @Input()
  heading2: string = 'Contact Information'
  @Input()
  content1: string =
    "We'd love to hear from you. Contact us for any inquiries or to discuss how we can help your business thrive."
  @Input()
  phone1: string = '+1-123-456-7890'
  @Input()
  address1: string = '123 Innovation Street, Tech City, USA'
  @Input()
  heading1: string = 'Get in Touch'
  @Input()
  content2: string =
    'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in ero.'
  @Input()
  content4: string =
    'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in ero.'
  @Input()
  heading3: string = 'Phone'
  @Input()
  link1: string = 'Start new chat'
  @Input()
  heading4: string = 'Office'
  constructor() {}
}
