import { Component, Input } from '@angular/core'

@Component({
  selector: 'app-stats1',
  templateUrl: 'stats1.component.html',
  styleUrls: ['stats1.component.css'],
})
export class Stats1 {
  @Input()
  heading1: string = 'Customer results presented in a fashion way'
  @Input()
  content2: string =
    'Business improvements emphasized with numbers to increase creadibility'
  @Input()
  image1Alt: string = 'image'
  @Input()
  content1: string = 'Customer Feedback'
  @Input()
  stat1: string = 'Customized Solutions'
  @Input()
  stat4: string = 'Cutting-Edge Technology'
  @Input()
  stat3: string = 'Competitive Advantage'
  @Input()
  image1Src: string =
    'https://images.unsplash.com/photo-1593376853899-fbb47a057fa0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyM3w&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  stat2Description: string =
    'Focus on quality and efficiency to drive innovation'
  @Input()
  stat1Description: string =
    'Tailored services to meet the unique needs of each business'
  @Input()
  stat2: string = 'Customer Satisfaction'
  @Input()
  stat4Description: string =
    'Revolutionizing businesses with innovative solutions'
  @Input()
  stat3Description: string = 'Helping businesses stay ahead in the market'
  constructor() {}
}
