import { Component, Input } from '@angular/core'

@Component({
  selector: 'app-testimonial16',
  templateUrl: 'testimonial16.component.html',
  styleUrls: ['testimonial16.component.css'],
})
export class Testimonial16 {
  @Input()
  author1Position: string = 'CEO, ABC Company'
  @Input()
  content1: string =
    'Read what our clients have to say about their experience working with RoyTechInnovations.'
  @Input()
  heading1: string = 'Testimonials'
  @Input()
  author2Src: string =
    'https://images.unsplash.com/photo-1459245330819-1b6d75fbaa35?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyM3w&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  author4Name: string = 'Sarah Wilson'
  @Input()
  author1Name: string = 'John Smith'
  @Input()
  author1Alt: string = 'CEO John Smith'
  @Input()
  review1: string =
    'RoyTechInnovations has truly transformed our business with their innovative solutions. We have seen a significant increase in efficiency and customer satisfaction since implementing their technology.'
  @Input()
  author4Alt: string = 'CFO Sarah Wilson'
  @Input()
  author2Name: string = 'Emily Johnson'
  @Input()
  review3: string =
    "I can't thank RoyTechInnovations enough for the positive impact they've had on our business. Their cutting-edge solutions have given us a competitive edge in the market."
  @Input()
  author3Alt: string = 'COO Michael Brown'
  @Input()
  author3Name: string = 'Michael Brown'
  @Input()
  author4Src: string =
    'https://images.unsplash.com/photo-1501432377862-3d0432b87a14?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNHw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  author4Position: string = 'CFO, GHI Industries'
  @Input()
  author2Position: string = 'CTO, XYZ Corporation'
  @Input()
  review4: string =
    'RoyTechInnovations exceeded our expectations in every way. Their commitment to customer satisfaction is evident in the results they deliver. We look forward to continuing our partnership.'
  @Input()
  review2: string =
    "Working with RoyTechInnovations was a game-changer for us. Their team's dedication to quality and attention to detail is unparalleled. We highly recommend their services."
  @Input()
  author1Src: string =
    'https://images.unsplash.com/photo-1469334031218-e382a71b716b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNHw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  author3Src: string =
    'https://images.unsplash.com/photo-1520283818086-3f6dffb019c0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNHw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  author3Position: string = 'COO, DEF Enterprises'
  @Input()
  author2Alt: string = 'CTO Emily Johnson'
  constructor() {}
}
