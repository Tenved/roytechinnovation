import { Component, Input } from '@angular/core'

@Component({
  selector: 'app-contact7',
  templateUrl: 'contact7.component.html',
  styleUrls: ['contact7.component.css'],
})
export class Contact7 {
  @Input()
  location1ImgSrc: string =
    'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTcwMjUzM3w&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  location2ImgSrc: string =
    'https://images.unsplash.com/photo-1554325139-bbd006cd3e5a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTcwMjUzM3w&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  location2Description: string = '456 Innovation Avenue, Tech Town, USA'
  @Input()
  location1: string = 'Headquarters'
  @Input()
  location2: string = 'Support Center'
  @Input()
  location1ImgAlt: string = 'Headquarters Image'
  @Input()
  heading1: string = 'Contact Us'
  @Input()
  location2ImgAlt: string = 'Support Center Image'
  @Input()
  content1: string =
    'For inquiries or to schedule a consultation, please contact us at headquarters@roytechinnovations.com'
  @Input()
  location1Description: string = '123 Innovation Street, Tech City, USA'
  constructor() {}
}
