import { Component, Input } from '@angular/core'

@Component({
  selector: 'app-features18',
  templateUrl: 'features18.component.html',
  styleUrls: ['features18.component.css'],
})
export class Features18 {
  @Input()
  feature1Description: string =
    'We offer customized solutions to meet the specific needs of each client, ensuring maximum efficiency and effectiveness.'
  @Input()
  feature1ImageSrc: string =
    'https://images.unsplash.com/photo-1695654402912-b2945fe32cab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxOTQxMjgxNXw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  feature1Slogan: string = 'Revolutionizing Businesses'
  @Input()
  feature1Title: string = 'Tailored Services'
  @Input()
  feature1ImageAlt: string = 'Innovative Solutions'
  constructor() {}
}
