import { Component, Input } from '@angular/core'

@Component({
  selector: 'app-faq1',
  templateUrl: 'faq1.component.html',
  styleUrls: ['faq1.component.css'],
})
export class FAQ1 {
  @Input()
  heading2: string = 'Still have a question?'
  @Input()
  faq4Question: string =
    'Are the solutions provided by RoyTechInnovations customizable?'
  @Input()
  content2: string = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. '
  @Input()
  faq3Question: string =
    'How does RoyTechInnovations help businesses stay ahead in the market?'
  @Input()
  faq2Question: string = "What is the focus of RoyTechInnovations' services?"
  @Input()
  faq5Answer: string =
    'The primary goal of RoyTechInnovations is to revolutionize businesses with cutting-edge solutions.'
  @Input()
  content1: string =
    'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique.'
  @Input()
  action1: string = 'Contact'
  @Input()
  faq1Answer: string =
    'RoyTechInnovations offers cutting-edge technology solutions tailored to meet the unique needs of each client.'
  @Input()
  heading1: string = 'FAQs'
  @Input()
  faq3Answer: string =
    'RoyTechInnovations has a dedicated team of experts driving innovation to help businesses stay competitive.'
  @Input()
  faq2Answer: string =
    'RoyTechInnovations focuses on quality, efficiency, and customer satisfaction in providing services.'
  @Input()
  faq4Answer: string =
    'Yes, RoyTechInnovations provides services tailored to meet the unique needs of each client.'
  @Input()
  faq1Question: string = 'What kind of solutions does RoyTechInnovations offer?'
  @Input()
  faq5Question: string = 'What is the primary goal of RoyTechInnovations?'
  constructor() {}
}
