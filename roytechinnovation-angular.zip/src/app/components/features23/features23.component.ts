import { Component, Input } from '@angular/core'

@Component({
  selector: 'app-features23',
  templateUrl: 'features23.component.html',
  styleUrls: ['features23.component.css'],
})
export class Features23 {
  @Input()
  content1: string =
    'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse varius enim in eros elementum tristique. Duis cursus, mi quis viverra ornare, eros dolor interdum nulla.'
  @Input()
  feature6Title: string = '24/7 Support'
  @Input()
  feature3ImageSrc: string =
    'https://images.unsplash.com/photo-1518349619113-03114f06ac3a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNnw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  feature6Description: string =
    'Our dedicated support team is available round the clock to assist clients with any queries or issues.'
  @Input()
  feature1ImageSrc: string =
    'https://images.unsplash.com/photo-1616410011236-7a42121dd981?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNXw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  feature4ImageSrc: string =
    'https://play.teleporthq.io/static/svg/default-img.svg'
  @Input()
  feature5Description: string =
    'Customer happiness is our top priority, and we strive to exceed expectations in every interaction.'
  @Input()
  feature4Description: string =
    'We streamline processes and optimize resources to enhance efficiency and productivity.'
  @Input()
  feature3ImageAlt: string = 'Quality Assurance Image'
  @Input()
  feature2Title: string = 'Innovation'
  @Input()
  feature6ImageSrc: string =
    'https://images.unsplash.com/photo-1556710808-a2bc27a448f2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNnw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  feature4ImageAlt: string = 'Efficiency Image'
  @Input()
  feature5ImageAlt: string = 'Customer Satisfaction Image'
  @Input()
  feature1ImageAlt: string = 'Tailored Solutions Image'
  @Input()
  feature3Description: string =
    'Our products and services undergo rigorous quality checks to ensure high standards are maintained.'
  @Input()
  feature1Title: string = 'Tailored Solutions'
  @Input()
  feature5Title: string = 'Customer Satisfaction'
  @Input()
  feature4Title: string = 'Efficiency'
  @Input()
  feature3Title: string = 'Quality Assurance'
  @Input()
  feature2Description: string =
    'We focus on cutting-edge technology and innovative solutions to drive business growth.'
  @Input()
  feature5ImageSrc: string =
    'https://images.unsplash.com/flagged/photo-1556637640-2c80d3201be8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNXw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  feature2ImageSrc: string =
    'https://images.unsplash.com/photo-1589828994425-cee7c6e8dbf8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTc2MzUyNHw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  heading1: string = 'Our Features'
  @Input()
  feature2ImageAlt: string = 'Innovation Image'
  @Input()
  action1: string = 'Learn More'
  @Input()
  feature1Description: string =
    'We provide customized services and products to meet the specific needs of each client.'
  @Input()
  feature6ImageAlt: string = '24/7 Support Image'
  constructor() {}
}
