import { Component, Input } from '@angular/core'

@Component({
  selector: 'app-stats2',
  templateUrl: 'stats2.component.html',
  styleUrls: ['stats2.component.css'],
})
export class Stats2 {
  @Input()
  image1Alt: string = 'RoyTechInnovations Stats Image'
  @Input()
  stat1: string = 'Tailored Solutions'
  @Input()
  stat2Description: string =
    'Focused on delivering high-quality and efficient solutions'
  @Input()
  stat4: string = 'Quality Assurance'
  @Input()
  stat3Description: string =
    'Dedicated to exceeding customer expectations and ensuring satisfaction'
  @Input()
  stat3: string = 'Customer Satisfaction'
  @Input()
  stat4Description: string =
    'Ensuring top-notch quality in all our products and services'
  @Input()
  heading1: string = 'Our Stats'
  @Input()
  stat2: string = 'Cutting-Edge Technology'
  @Input()
  stat1Description: string =
    "Providing personalized services tailored to each client's unique requirements"
  @Input()
  image1Src: string =
    'https://images.unsplash.com/photo-1548100721-15f0e76035c8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTcwMDU5MHw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  content1: string =
    'Customized services and products to meet your specific business needs'
  @Input()
  content2: string =
    'Innovative technology solutions designed for efficiency and effectiveness'
  constructor() {}
}
