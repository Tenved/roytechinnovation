import { Component, Input } from '@angular/core'

@Component({
  selector: 'contact-form3',
  templateUrl: 'contact-form3.component.html',
  styleUrls: ['contact-form3.component.css'],
})
export class ContactForm3 {
  @Input()
  imageAlt: string = 'Image1'
  @Input()
  content1: string = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. '
  @Input()
  heading1: string = 'Contact us'
  @Input()
  action: string = '/submit_contact_form'
  @Input()
  content2: string = 'Get in touch with us'
  @Input()
  imageSrc: string =
    'https://images.unsplash.com/photo-1453726007388-5df12357fcc6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTcwMjUzNHw&ixlib=rb-4.0.3&q=80&w=1080'
  constructor() {}
}
