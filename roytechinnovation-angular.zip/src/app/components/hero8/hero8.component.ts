import { Component, Input } from '@angular/core'

@Component({
  selector: 'app-hero8',
  templateUrl: 'hero8.component.html',
  styleUrls: ['hero8.component.css'],
})
export class Hero8 {
  @Input()
  image1Alt: string = 'RoyTechInnovations Logo'
  @Input()
  action1: string = 'Learn More'
  @Input()
  heading1: string = 'Welcome to RoyTechInnovations'
  @Input()
  action2: string = 'Contact Us'
  @Input()
  image1Src: string =
    'https://images.unsplash.com/photo-1507925921958-8a62f3d1a50d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTcxNTcwMDU5MHw&ixlib=rb-4.0.3&q=80&w=1080'
  @Input()
  content1: string =
    'Revolutionize your business with cutting-edge technological solutions'
  constructor() {}
}
