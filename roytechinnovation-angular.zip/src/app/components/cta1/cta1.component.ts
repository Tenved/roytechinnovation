import { Component, Input } from '@angular/core'

@Component({
  selector: 'app-cta1',
  templateUrl: 'cta1.component.html',
  styleUrls: ['cta1.component.css'],
})
export class CTA1 {
  @Input()
  action2: string = 'Learn more about our services'
  @Input()
  heading1: string = 'Ready to revolutionize your business?'
  @Input()
  content1: string =
    'Contact us today to discuss how our cutting-edge technological solutions can drive innovation and help your business stay competitive.'
  @Input()
  action1: string = 'Schedule a consultation'
  constructor() {}
}
